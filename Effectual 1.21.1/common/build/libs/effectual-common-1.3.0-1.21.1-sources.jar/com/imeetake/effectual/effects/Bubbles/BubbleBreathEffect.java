package com.imeetake.effectual.effects.Bubbles;

import com.imeetake.effectual.EffectualConfig;
import com.imeetake.tlib.client.particle.TClientParticles;
import dev.architectury.event.events.client.ClientTickEvent;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import net.minecraft.class_1657;
import net.minecraft.class_2398;
import net.minecraft.class_243;
import net.minecraft.class_3532;
import net.minecraft.class_5819;

public class BubbleBreathEffect {
    private static final class_5819 RANDOM = class_5819.method_43047();
    private static final Map<Integer, Integer> lastAirValues = new HashMap<>();
    private static final Map<Integer, Integer> breathingTimers = new HashMap<>();

    private static int cleanupTimer = 0;

    public static void register() {
        ClientTickEvent.CLIENT_POST.register(client -> {
            if (!EffectualConfig.get().bubbleBreath || client.field_1687 == null || client.method_1493()) return;

            if (++cleanupTimer >= 100) {
                cleanupMap(client.field_1687.method_18456());
                cleanupTimer = 0;
            }

            for (class_1657 player : client.field_1687.method_18456()) {
                int id = player.method_5628();

                if (shouldPlayEffect(player)) {
                    int currentAir = player.method_5669();
                    int previousAir = lastAirValues.getOrDefault(id, currentAir);
                    lastAirValues.put(id, currentAir);

                    boolean airDecreased = currentAir < previousAir;
                    boolean uiBubblePopped = (currentAir % 30 == 0) && currentAir < 300;

                    if (airDecreased && uiBubblePopped) {
                        breathingTimers.put(id, 8);
                    }
                } else {
                    lastAirValues.remove(id);
                    breathingTimers.remove(id);
                }

                int breatheTicks = breathingTimers.getOrDefault(id, 0);
                if (breatheTicks > 0) {
                    processBreathTick(player);
                    breathingTimers.put(id, breatheTicks - 1);
                }
            }
        });
    }

    private static void cleanupMap(java.util.List<? extends class_1657> activePlayers) {
        Iterator<Integer> iterator = lastAirValues.keySet().iterator();
        while (iterator.hasNext()) {
            Integer id = iterator.next();
            if (activePlayers.stream().noneMatch(p -> p.method_5628() == id)) {
                iterator.remove();
                breathingTimers.remove(id);
            }
        }
    }

    private static boolean shouldPlayEffect(class_1657 player) {
        return player.method_5869()
                && !player.method_7325()
                && !player.method_7337();
    }

    private static void processBreathTick(class_1657 player) {
        float xRot = player.method_36455();
        float yRot = player.method_36454();

        float xRotRad = xRot * ((float) Math.PI / 180F);
        float yRotRad = -yRot * ((float) Math.PI / 180F);

        double lookX = class_3532.method_15374(yRotRad) * class_3532.method_15362(xRotRad);
        double lookY = -class_3532.method_15374(xRotRad);
        double lookZ = class_3532.method_15362(yRotRad) * class_3532.method_15362(xRotRad);

        double mouthOffsetForward = 0.25;
        double mouthOffsetDown = 0.15;

        double originX = player.method_23317() + (lookX * mouthOffsetForward);
        double originY = player.method_23320() - mouthOffsetDown + (lookY * mouthOffsetForward);
        double originZ = player.method_23321() + (lookZ * mouthOffsetForward);
        class_243 playerVel = player.method_18798();

        if (RANDOM.method_43056()) {
            double velocityX = (lookX * 0.1) + (playerVel.field_1352 * 0.8);
            double velocityY = (lookY * 0.1) + (playerVel.field_1351 * 0.8) + 0.05;
            double velocityZ = (lookZ * 0.1) + (playerVel.field_1350 * 0.8);

            TClientParticles.spawn(
                    class_2398.field_11247,
                    originX, originY, originZ,
                    velocityX, velocityY, velocityZ
            );
        }
    }
}