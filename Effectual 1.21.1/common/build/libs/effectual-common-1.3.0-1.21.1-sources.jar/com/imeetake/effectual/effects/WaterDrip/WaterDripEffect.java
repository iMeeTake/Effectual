package com.imeetake.effectual.effects.WaterDrip;

import com.imeetake.effectual.EffectualConfig;
import com.imeetake.effectual.ModParticles;
import com.imeetake.tlib.client.particle.TClientParticles;
import dev.architectury.event.events.client.ClientTickEvent;
import java.util.Map;
import java.util.WeakHashMap;
import net.minecraft.class_1657;
import net.minecraft.class_5819;
import net.minecraft.class_638;

public class WaterDripEffect {
    private static final class_5819 RANDOM = class_5819.method_43047();
    private static final Map<class_1657, Long> lastFullySubmergedTicks = new WeakHashMap<>();

    public static void register() {
        ClientTickEvent.CLIENT_POST.register(client -> {
            if (!EffectualConfig.get().waterDrip || client.field_1687 == null || client.method_1493()) return;
            class_638 level = client.field_1687;
            for (class_1657 player : level.method_18456()) {
                if (shouldPlayEffect(player)) spawnWaterDripParticles(player);
            }
        });
    }

    private static boolean shouldPlayEffect(class_1657 player) {
        if (player.method_7325() || player.method_7337()) return false;
        long time = player.method_37908().method_8510();

        if (player.method_5869()) {
            lastFullySubmergedTicks.put(player, time);
            return false;
        }

        long last = lastFullySubmergedTicks.getOrDefault(player, -200L);
        if (time - last > 100) return false;

        if (player.method_5799()) return true;

        return player.method_18798().method_1027() > 0.0004 || player.method_5624();
    }

    private static void spawnWaterDripParticles(class_1657 player) {
        int count = 1 + (RANDOM.method_43057() < 0.12f ? 1 : 0);
        float yaw = player.method_36454();
        double ry = Math.toRadians(-yaw);

        for (int i = 0; i < count; i++) {
            double ring = 0.32 + RANDOM.method_43058() * 0.08;
            double ang = RANDOM.method_43058() * Math.PI * 2.0;
            double lx = Math.cos(ang) * ring;
            double lz = Math.sin(ang) * ring;
            double ly = 0.95 + RANDOM.method_43058() * 0.7;

            double rx = lx * Math.cos(ry) - lz * Math.sin(ry);
            double rz = lx * Math.sin(ry) + lz * Math.cos(ry);

            double x = player.method_23317() + rx;
            double y = player.method_23318() + ly;
            double z = player.method_23321() + rz;

            TClientParticles.spawn(ModParticles.WATER_DRIP.get(), x, y, z, 0, 0, 0);
        }
    }
}