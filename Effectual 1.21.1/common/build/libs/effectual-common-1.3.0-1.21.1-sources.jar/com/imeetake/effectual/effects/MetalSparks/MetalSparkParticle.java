package com.imeetake.effectual.effects.MetalSparks;

import net.minecraft.class_2400;
import net.minecraft.class_3999;
import net.minecraft.class_4002;
import net.minecraft.class_4003;
import net.minecraft.class_638;
import net.minecraft.class_703;
import net.minecraft.class_707;
import org.jetbrains.annotations.Nullable;

public class MetalSparkParticle extends class_4003 {

    private final float rotSpeed;
    private final float baseSize;

    public MetalSparkParticle(
            class_638 level,
            double x, double y, double z,
            double velocityX, double velocityY, double velocityZ
    ) {
        super(level, x, y, z, velocityX, velocityY, velocityZ);

        this.baseSize = 0.015F * (1.0F + field_3840.method_43057() * 0.5F);
        this.field_17867 = this.baseSize;

        this.field_3847 = 20 + this.field_3840.method_43048(10);
        this.field_3862 = true;
        this.field_3844 = 1.0F;

        this.field_3852 = velocityX;
        this.field_3869 = velocityY + 0.1;
        this.field_3850 = velocityZ;

        float baseBrightness = 0.9f + field_3840.method_43057() * 0.1f;
        float r = baseBrightness * (0.9f + field_3840.method_43057() * 0.1f);
        float g = baseBrightness * (0.5f + field_3840.method_43057() * 0.4f);
        float b = baseBrightness * field_3840.method_43057() * 0.2f;

        this.method_3084(r, g, b);
        this.field_3841 = 1.0F;

        this.rotSpeed = (this.field_3840.method_43057() - 0.5F) * 0.3F;
        this.field_3839 = this.field_3840.method_43057() * (float) (Math.PI * 2);
        this.field_3857 = this.field_3839;
    }

    @Override
    public void method_3070() {
        this.field_3858 = this.field_3874;
        this.field_3838 = this.field_3854;
        this.field_3856 = this.field_3871;

        if (this.field_3866++ >= this.field_3847) {
            this.method_3085();
            return;
        }

        this.field_3857 = this.field_3839;
        this.field_3839 += this.rotSpeed;

        this.field_3869 -= 0.04D * (double) this.field_3844;
        this.method_3069(this.field_3852, this.field_3869, this.field_3850);

        this.field_3852 *= 0.9;
        this.field_3869 *= 0.9;
        this.field_3850 *= 0.9;

        if (this.field_3845) {
            this.field_3852 *= 0.7;
            this.field_3850 *= 0.7;
        }

        int fadeTime = 5;
        if (this.field_3866 > this.field_3847 - fadeTime) {
            float fadeProgress = (float) (this.field_3866 - (this.field_3847 - fadeTime)) / (float) fadeTime;
            this.field_17867 = this.baseSize * (1.0F - fadeProgress);
        }
    }

    @Override
    public int method_3068(float partialTick) {
        return 15728880;
    }

    @Override
    public class_3999 method_18122() {
        return class_3999.field_17829;
    }

    public static class Factory implements class_707<class_2400> {
        private final class_4002 spriteSet;

        public Factory(class_4002 spriteSet) {
            this.spriteSet = spriteSet;
        }

        @Nullable
        @Override
        public class_703 createParticle(class_2400 type, class_638 level, double x, double y, double z, double dx, double dy, double dz) {
            MetalSparkParticle particle = new MetalSparkParticle(level, x, y, z, dx, dy, dz);
            particle.method_18140(this.spriteSet);
            return particle;
        }
    }
}