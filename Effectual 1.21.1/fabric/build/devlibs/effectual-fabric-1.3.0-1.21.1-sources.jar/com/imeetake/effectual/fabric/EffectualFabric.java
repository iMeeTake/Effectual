package com.imeetake.effectual.fabric;

import com.imeetake.effectual.EffectualClient;
import net.fabricmc.api.ModInitializer;

import com.imeetake.effectual.Effectual;

public final class EffectualFabric implements ModInitializer {
    @Override
    public void onInitialize() {
        // This code runs as soon as Minecraft is in a mod-load-ready state.
        // However, some things (like resources) may still be uninitialized.
        // Proceed with mild caution.

        // Run our common setup.
        Effectual.init();
    }
}
