package com.imeetake.effectual.effects.Bubbles;

import com.imeetake.effectual.EffectualConfig;
import com.imeetake.tlib.client.particle.TClientParticles;
import dev.architectury.event.events.client.ClientTickEvent;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_2398;
import net.minecraft.class_2586;
import net.minecraft.class_2595;
import net.minecraft.class_2611;
import net.minecraft.class_5819;
import net.minecraft.class_638;

public class BubbleChestEffect {
    private static final class_5819 RAND = class_5819.method_43047();
    private static final int RADIUS = 5;
    private static final int SAMPLES_PER_TICK = 64;

    public static void register() {
        ClientTickEvent.CLIENT_POST.register(client -> {
            if (!EffectualConfig.get().bubbleChests || client.field_1687 == null || client.method_1493()) return;
            if (client.field_1724 == null) return;

            class_638 level = client.field_1687;
            class_2338 center = client.field_1724.method_24515();
            class_2338.class_2339 posM = new class_2338.class_2339();

            for (int i = 0; i < SAMPLES_PER_TICK; i++) {
                int dx = RAND.method_43048(RADIUS * 2 + 1) - RADIUS;
                int dy = RAND.method_43048(RADIUS * 2 + 1) - RADIUS;
                int dz = RAND.method_43048(RADIUS * 2 + 1) - RADIUS;

                posM.method_10103(center.method_10263() + dx, center.method_10264() + dy, center.method_10260() + dz);

                if (!level.method_8316(posM).method_15771()) continue;

                if (!level.method_8320(posM).method_27852(class_2246.field_10034)
                        && !level.method_8320(posM).method_27852(class_2246.field_10443)) {
                    continue;
                }

                class_2586 be = level.method_8321(posM);
                boolean open = false;

                if (be instanceof class_2595 chest) {
                    open = chest.method_11274(0) > 0;
                } else if (be instanceof class_2611 ender) {
                    open = ender.method_11274(0) > 0;
                }

                if (!open) continue;

                double px = posM.method_10263() + 0.4 + RAND.method_43058() * 0.2;
                double py = posM.method_10264() + 0.8;
                double pz = posM.method_10260() + 0.4 + RAND.method_43058() * 0.2;

                TClientParticles.spawn(class_2398.field_11247, px, py, pz, 0, 0.1, 0);
            }
        });
    }
}