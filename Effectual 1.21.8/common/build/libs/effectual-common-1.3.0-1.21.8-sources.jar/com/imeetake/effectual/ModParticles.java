package com.imeetake.effectual;

import com.imeetake.tlib.client.particle.TParticles;
import dev.architectury.registry.registries.DeferredRegister;
import dev.architectury.registry.registries.RegistrySupplier;
import net.minecraft.class_2396;
import net.minecraft.class_2400;
import net.minecraft.class_7924;

public class ModParticles {
    public static final DeferredRegister<class_2396<?>> PARTICLE_TYPES =
            DeferredRegister.create(Effectual.MOD_ID, class_7924.field_41210);

    public static final RegistrySupplier<class_2400> SAND_DUST =
            PARTICLE_TYPES.register("sand_dust", () -> new class_2400(false) {
            });
    public static final RegistrySupplier<class_2400> RED_SAND_DUST =
            PARTICLE_TYPES.register("red_sand_dust", () -> new class_2400(false) {
            });
    public static final RegistrySupplier<class_2400> SNOW_DUST =
            PARTICLE_TYPES.register("snow_dust", () -> new class_2400(false) {
            });
    public static final RegistrySupplier<class_2400> GRAVEL_DUST =
            PARTICLE_TYPES.register("gravel_dust", () -> new class_2400(false) {
            });
    public static final RegistrySupplier<class_2400> MUD_DUST =
            PARTICLE_TYPES.register("mud_dust", () -> new class_2400(false) {
            });

    public static final RegistrySupplier<class_2400> MOUTH_STEAM =
            PARTICLE_TYPES.register("mouth_steam", () -> new class_2400(false) {
            });
    public static final RegistrySupplier<class_2400> WATER_DRIP =
            PARTICLE_TYPES.register("water_drip", () -> new class_2400(false) {
            });
    public static final RegistrySupplier<class_2400> METAL_SPARK =
            PARTICLE_TYPES.register("metal_spark", () -> new class_2400(false) {
            });
    public static final RegistrySupplier<class_2400> ENTITY_SPARK =
            PARTICLE_TYPES.register("entity_spark", () -> new class_2400(false) {
            });


    public static final RegistrySupplier<class_2400> AIR_TRAIL =
            TParticles.simple(PARTICLE_TYPES, "air_trail");
    public static final RegistrySupplier<class_2400> GOLD_GLOW =
            TParticles.simple(PARTICLE_TYPES, "gold_glow");
    public static final RegistrySupplier<class_2400> SOUL_GLOW =
            TParticles.simple(PARTICLE_TYPES, "soul_glow");
    public static final RegistrySupplier<class_2400> SPARK =
            TParticles.simple(PARTICLE_TYPES, "spark");
    public static final RegistrySupplier<class_2400> SOUL_SPARK =
            TParticles.simple(PARTICLE_TYPES, "soul_spark");


    public static void register() {
        PARTICLE_TYPES.register();
    }
}