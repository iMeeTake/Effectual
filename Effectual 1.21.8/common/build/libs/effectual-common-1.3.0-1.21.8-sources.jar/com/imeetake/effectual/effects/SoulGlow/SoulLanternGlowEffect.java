package com.imeetake.effectual.effects.SoulGlow;

import com.imeetake.effectual.EffectualConfig;
import com.imeetake.effectual.ModParticles;
import com.imeetake.tlib.client.particle.TClientParticles;
import dev.architectury.event.events.client.ClientTickEvent;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_310;
import net.minecraft.class_5819;

public class SoulLanternGlowEffect {

    private static final class_5819 RAND = class_5819.method_43047();
    private static final int SAMPLES_PER_TICK = 100;
    private static final int RADIUS = 6;

    public static void register() {
        ClientTickEvent.CLIENT_POST.register(client -> {
            if (!EffectualConfig.get().lanternImprovements
                    || client.field_1687 == null
                    || client.field_1724 == null
                    || client.method_1493())
                return;

            spawnNearPlayer(client);
        });
    }

    private static void spawnNearPlayer(class_310 client) {
        class_2338 center = client.field_1724.method_24515();
        class_2338.class_2339 pos = new class_2338.class_2339();

        int startX = center.method_10263();
        int startY = center.method_10264();
        int startZ = center.method_10260();

        for (int i = 0; i < SAMPLES_PER_TICK; i++) {
            int dx = RAND.method_43048(RADIUS * 2 + 1) - RADIUS;
            int dy = RAND.method_43048(5) - 2;
            int dz = RAND.method_43048(RADIUS * 2 + 1) - RADIUS;

            pos.method_10103(startX + dx, startY + dy, startZ + dz);
            class_2680 state = client.field_1687.method_8320(pos);

            if (!state.method_27852(class_2246.field_22110)) continue;

            glow(pos);
        }
    }

    private static void glow(class_2338 pos) {
        double x = pos.method_10263() + 0.5 + (RAND.method_43058() - 0.5) * 0.55;
        double y = pos.method_10264() + 0.15;
        double z = pos.method_10260() + 0.5 + (RAND.method_43058() - 0.5) * 0.55;

        TClientParticles.spawn(
                ModParticles.SOUL_GLOW.get(),
                x, y, z,
                0, -0.002, 0
        );
    }
}