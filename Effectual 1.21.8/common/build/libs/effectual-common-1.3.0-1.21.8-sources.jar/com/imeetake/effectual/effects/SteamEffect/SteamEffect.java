package com.imeetake.effectual.effects.SteamEffect;

import com.imeetake.effectual.EffectualConfig;
import com.imeetake.tlib.client.particle.TClientParticles;
import dev.architectury.event.events.client.ClientTickEvent;
import java.util.HashSet;
import java.util.Set;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_2398;
import net.minecraft.class_2680;
import net.minecraft.class_310;
import net.minecraft.class_3486;
import net.minecraft.class_5819;

public class SteamEffect {

    private static final Set<class_2338> activeSteamPositions = new HashSet<>();
    private static final class_5819 RANDOM = class_5819.method_43047();

    private static final int POSITIONS_PER_TICK = 462;
    private static final int RADIUS = 20;
    private static final int HEIGHT = 5;

    private static int scanX = -RADIUS;
    private static int scanY = -HEIGHT;
    private static int scanZ = -RADIUS;


    public static void register() {
        ClientTickEvent.CLIENT_POST.register(client -> {
            if (!EffectualConfig.get().steamEffect) return;
            if (client.field_1687 == null || client.field_1724 == null) return;
            if (client.method_1493()) return;

            updateSteamPositions(client);

            for (class_2338 pos : activeSteamPositions) {
                spawnSteam(pos);
            }
        });
    }

    private static void updateSteamPositions(class_310 client) {
        class_2338 center = client.field_1724.method_24515();
        class_2338.class_2339 pos = new class_2338.class_2339();
        int checkedCount = 0;

        while (checkedCount < POSITIONS_PER_TICK) {

            pos.method_10103(center.method_10263() + scanX, center.method_10264() + scanY, center.method_10260() + scanZ);

            boolean isSteam = isWaterNextToLava(client, pos);
            if (isSteam) {
                activeSteamPositions.add(pos.method_10062());
            } else {
                activeSteamPositions.remove(pos);
            }

            if (++scanX > RADIUS) {
                scanX = -RADIUS;
                if (++scanZ > RADIUS) {
                    scanZ = -RADIUS;
                    if (++scanY > HEIGHT) {
                        scanY = -HEIGHT;
                    }
                }
            }
            checkedCount++;
        }
    }

    private static boolean isWaterNextToLava(class_310 client, class_2338 pos) {
        class_2680 state = client.field_1687.method_8320(pos);
        if (!state.method_26227().method_15767(class_3486.field_15517)) return false;

        for (int dx = -1; dx <= 1; dx++) {
            for (int dy = -1; dy <= 1; dy++) {
                for (int dz = -1; dz <= 1; dz++) {
                    if (dx == 0 && dy == 0 && dz == 0) continue;

                    class_2338 neighborPos = pos.method_10069(dx, dy, dz);
                    class_2680 neighbor = client.field_1687.method_8320(neighborPos);

                    if (neighbor.method_26227().method_15767(class_3486.field_15518) || neighbor.method_27852(class_2246.field_27098)) {
                        return true;
                    }
                }
            }
        }
        return false;
    }

    private static void spawnSteam(class_2338 pos) {
        int count = RANDOM.method_43048(2) + 1;
        for (int i = 0; i < count; i++) {
            double x = pos.method_10263() + 0.5 + (RANDOM.method_43058() - 0.5) * 0.3;
            double y = pos.method_10264() + 1.0 + RANDOM.method_43058() * 0.2;
            double z = pos.method_10260() + 0.5 + (RANDOM.method_43058() - 0.5) * 0.3;

            TClientParticles.spawn(
                    class_2398.field_11203,
                    x, y, z,
                    0.0, 0.1 + RANDOM.method_43058() * 0.05, 0.0
            );
        }
    }
}