package com.imeetake.effectual.mixin;

import com.imeetake.effectual.EffectualConfig;
import com.imeetake.tlib.client.particle.TClientParticles;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2388;
import net.minecraft.class_2398;
import net.minecraft.class_2680;
import net.minecraft.class_310;
import net.minecraft.class_3965;
import net.minecraft.class_5819;
import net.minecraft.class_636;
import net.minecraft.class_638;
import net.minecraft.class_746;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_636.class)
public class BlockPlaceMixin {

    @Inject(method = "useItemOn", at = @At("TAIL"))
    private void onBlockPlace(class_746 player, class_1268 hand, class_3965 hitResult, CallbackInfoReturnable<class_1269> cir) {
        if (!EffectualConfig.get().blockPlaceEffect) return;

        if (!cir.getReturnValue().method_23665()) return;

        class_638 world = class_310.method_1551().field_1687;
        if (world == null) return;

        class_2338 placedBlockPos = hitResult.method_17777().method_10093(hitResult.method_17780());
        class_2680 state = world.method_8320(placedBlockPos);
        class_2248 block = state.method_26204();

        if (block == class_2246.field_10477 || block == class_2246.field_10491 || block == class_2246.field_27879 ||
                block == class_2246.field_10102 || block == class_2246.field_42728 ||
                block == class_2246.field_10255 || block == class_2246.field_43227 ||
                block == class_2246.field_10534) {

            class_5819 random = world.field_9229;

            for (int i = 0; i < 12; i++) {
                TClientParticles.spawn(
                        new class_2388(class_2398.field_11217, state),
                        placedBlockPos.method_10263() + random.method_43058(),
                        placedBlockPos.method_10264() + 0.2,
                        placedBlockPos.method_10260() + random.method_43058(),
                        (random.method_43058() - 0.5) * 0.1,
                        random.method_43058() * 0.1,
                        (random.method_43058() - 0.5) * 0.1
                );
            }
        }
    }
}