package com.imeetake.effectual.effects.PlayerRunEffect.DustParticles;

import com.imeetake.effectual.effects.PlayerRunEffect.RunDustParticle;
import net.minecraft.class_2400;
import net.minecraft.class_4002;
import net.minecraft.class_638;
import net.minecraft.class_703;
import net.minecraft.class_707;
import org.jetbrains.annotations.Nullable;

public class GravelDustParticle extends RunDustParticle {

    public GravelDustParticle(class_638 level, double x, double y, double z, double vx, double vy, double vz) {
        super(level, x, y, z, vx, vy, vz, Weight.HEAVY, 0.45F, 0.42F, 0.45F);
    }

    public static class Factory implements class_707<class_2400> {
        private final class_4002 spriteSet;

        public Factory(class_4002 spriteSet) {
            this.spriteSet = spriteSet;
        }

        @Nullable
        @Override
        public class_703 createParticle(class_2400 type, class_638 level, double x, double y, double z, double dx, double dy, double dz) {
            GravelDustParticle p = new GravelDustParticle(level, x, y, z, dx, dy, dz);
            p.method_18140(this.spriteSet);
            return p;
        }
    }
}