package com.imeetake.effectual.effects.CauldronFill;

import com.imeetake.effectual.EffectualConfig;
import com.imeetake.tlib.client.particle.TClientParticles;
import dev.architectury.event.events.client.ClientTickEvent;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_239;
import net.minecraft.class_2398;
import net.minecraft.class_2680;
import net.minecraft.class_2741;
import net.minecraft.class_2758;
import net.minecraft.class_310;
import net.minecraft.class_3965;
import net.minecraft.class_5819;

public class CauldronFillEffect {

    private enum Kind {EMPTY, WATER, LAVA, POWDER}

    private static final class Snapshot {
        final Kind kind;
        final int level;

        Snapshot(Kind k, int l) {
            this.kind = k;
            this.level = l;
        }
    }

    private static final Map<Long, Snapshot> stateCache = new HashMap<>();
    private static final class_5819 RAND = class_5819.method_43047();

    private static int backgroundScanTimer = 0;
    private static int cleanupTimer = 0;

    public static void register() {
        ClientTickEvent.CLIENT_POST.register(client -> {
            if (!EffectualConfig.get().cauldronFillEffect
                    || client.field_1687 == null
                    || client.field_1724 == null
                    || client.method_1493())
                return;

            scanTargetedBlock(client);

            if (++backgroundScanTimer >= 10) {
                scanArea(client);
                backgroundScanTimer = 0;
            }

            if (++cleanupTimer >= 100) {
                cleanup(client.field_1724.method_24515());
                cleanupTimer = 0;
            }
        });
    }

    private static void scanTargetedBlock(class_310 client) {
        class_239 hit = client.field_1765;
        if (hit == null || hit.method_17783() != class_239.class_240.field_1332) return;

        class_3965 blockHit = (class_3965) hit;
        class_2338 pos = blockHit.method_17777();

        if (client.field_1724.method_5649(pos.method_10263() + 0.5, pos.method_10264() + 0.5, pos.method_10260() + 0.5) > 36) return;

        checkBlock(client, pos.method_10263(), pos.method_10264(), pos.method_10260());
    }

    private static void scanArea(class_310 client) {
        class_2338 center = client.field_1724.method_24515();
        int radius = 6;
        int cx = center.method_10263();
        int cy = center.method_10264();
        int cz = center.method_10260();

        for (int dx = -radius; dx <= radius; dx++) {
            for (int dy = -1; dy <= 2; dy++) {
                for (int dz = -radius; dz <= radius; dz++) {
                    checkBlock(client, cx + dx, cy + dy, cz + dz);
                }
            }
        }
    }

    /**
     * Единая логика проверки состояния блока
     */
    private static void checkBlock(class_310 client, int x, int y, int z) {
        class_2338.class_2339 pos = new class_2338.class_2339(x, y, z);
        class_2680 state = client.field_1687.method_8320(pos);

        Kind kind = kindOf(state.method_26204());
        if (kind == null) return;

        long posKey = class_2338.method_10064(x, y, z);
        int level = currentLevel(state, kind);
        Snapshot prev = stateCache.get(posKey);

        if (prev == null) {
            stateCache.put(posKey, new Snapshot(kind, level));
            return;
        }

        boolean changed = false;

        if (kind != prev.kind) {
            if (kind != Kind.EMPTY) {
                spawnBurst(pos, kind, Math.max(1, level));
            }
            changed = true;
        } else if (level > prev.level) {
            spawnBurst(pos, kind, level - prev.level);
            changed = true;
        } else if (level != prev.level) {
            changed = true;
        }

        if (changed) {
            stateCache.put(posKey, new Snapshot(kind, level));
        }
    }

    private static void cleanup(class_2338 center) {
        long maxDistSqr = 16 * 16;
        Iterator<Map.Entry<Long, Snapshot>> it = stateCache.entrySet().iterator();

        int cx = center.method_10263();
        int cy = center.method_10264();
        int cz = center.method_10260();

        while (it.hasNext()) {
            long posLong = it.next().getKey();
            int x = class_2338.method_10061(posLong);
            int y = class_2338.method_10071(posLong);
            int z = class_2338.method_10083(posLong);

            double dX = cx - x;
            double dY = cy - y;
            double dZ = cz - z;
            double distSqr = dX * dX + dY * dY + dZ * dZ;

            if (distSqr > maxDistSqr) {
                it.remove();
            }
        }
    }

    private static Kind kindOf(class_2248 b) {
        if (b == class_2246.field_10593) return Kind.EMPTY;
        if (b == class_2246.field_27097) return Kind.WATER;
        if (b == class_2246.field_27098) return Kind.LAVA;
        if (b == class_2246.field_27878) return Kind.POWDER;
        return null;
    }

    private static int currentLevel(class_2680 s, Kind k) {
        if (k == Kind.WATER || k == Kind.POWDER) {
            class_2758 p = class_2741.field_12513;
            return s.method_28498(p) ? s.method_11654(p) : 0;
        }
        if (k == Kind.LAVA) return 3;
        return 0;
    }

    private static void spawnBurst(class_2338 pos, Kind kind, int delta) {
        double x = pos.method_10263() + 0.5;
        double y = pos.method_10264() + 0.94;
        double z = pos.method_10260() + 0.5;

        int base = kind == Kind.WATER ? 6 : kind == Kind.LAVA ? 5 : 7;
        int count = base + RAND.method_43048(3) + Math.min(4, delta * 2);

        for (int i = 0; i < count; i++) {
            double ox = (RAND.method_43058() - 0.5) * 0.6;
            double oz = (RAND.method_43058() - 0.5) * 0.6;
            double vx = (RAND.method_43058() - 0.5) * 0.05;
            double vz = (RAND.method_43058() - 0.5) * 0.05;

            switch (kind) {
                case WATER -> {
                    double vy = 0.05 + RAND.method_43058() * 0.05;
                    TClientParticles.spawn(class_2398.field_11202, x + ox, y, z + oz, vx, vy, vz);
                    if (RAND.method_43057() < 0.4f) {
                        TClientParticles.spawn(class_2398.field_11247, x + ox * 0.7, y - 0.2, z + oz * 0.7, 0, 0.02 + RAND.method_43058() * 0.02, 0);
                    }
                }
                case LAVA -> {
                    double vy = 0.04 + RAND.method_43058() * 0.04;
                    TClientParticles.spawn(class_2398.field_11239, x + ox, y, z + oz, vx, vy, vz);
                    if (RAND.method_43057() < 0.3f) {
                        TClientParticles.spawn(class_2398.field_11251, x + ox, y + 0.1, z + oz, 0, 0.02, 0);
                    }
                }
                case POWDER -> {
                    double vy = 0.03 + RAND.method_43058() * 0.04;
                    TClientParticles.spawn(class_2398.field_28013, x + ox, y + 0.1, z + oz, vx * 0.5, vy, vz * 0.5);
                }
                default -> {
                }
            }
        }
    }
}