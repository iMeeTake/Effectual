package com.imeetake.effectual.effects.FireEntitySparks;

import com.imeetake.effectual.EffectualConfig;
import com.imeetake.effectual.ModParticles;
import com.imeetake.tlib.client.particle.TClientParticles;
import net.minecraft.class_1297;
import net.minecraft.class_243;
import net.minecraft.class_310;
import net.minecraft.class_5819;

public class FireEntitySparksEffect {
    private static final class_5819 RAND = class_5819.method_43047();

    public static void tick(class_1297 e) {
        if (!EffectualConfig.get().fireEntitySparks) return;
        if (RAND.method_43057() >= 0.2f) return;

        class_310 mc = class_310.method_1551();
        if (mc.field_1724 != null && e.method_5858(mc.field_1724) > 256) return;

        spark(e);
    }

    private static void spark(class_1297 e) {
        double w = e.method_17681();
        double h = e.method_17682();
        class_243 vel = e.method_18798();

        double spawnWidth = w + 0.25;

        double x = e.method_23317() + (RAND.method_43058() - 0.5) * spawnWidth;
        double y = e.method_23318() + (RAND.method_43058() * (h + 0.2)) - 0.1;
        double z = e.method_23321() + (RAND.method_43058() - 0.5) * spawnWidth;

        int n = 1 + RAND.method_43048(2);

        for (int i = 0; i < n; i++) {
            double angle = RAND.method_43058() * Math.PI * 2;
            double driftSpeed = 0.01 + RAND.method_43058() * 0.02;

            double dx = vel.field_1352 + Math.cos(angle) * driftSpeed;
            double dy = vel.field_1351 + 0.04 + RAND.method_43058() * 0.05;
            double dz = vel.field_1350 + Math.sin(angle) * driftSpeed;

            TClientParticles.spawn(ModParticles.ENTITY_SPARK.get(), x, y, z, dx, dy, dz);
        }
    }
}