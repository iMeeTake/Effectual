package com.imeetake.effectual.effects.SparksSoul;

import com.imeetake.effectual.EffectualConfig;
import com.imeetake.effectual.ModParticles;
import com.imeetake.tlib.client.particle.TClientParticles;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_5819;

public class SoulCampfireImprovements {

    public static void animateTick(class_1937 level, class_2338 pos, class_5819 random) {
        if (!EffectualConfig.get().campfireImprovements) return;
        if (random.method_43057() < 0.4f) {
            spark(pos, random);
        }
    }

    private static void spark(class_2338 pos, class_5819 random) {
        double x = pos.method_10263() + 0.5;
        double y = pos.method_10264() + 0.65;
        double z = pos.method_10260() + 0.5;

        double ox = (random.method_43058() - 0.5) * 0.45;
        double oy = random.method_43058() * 0.35;
        double oz = (random.method_43058() - 0.5) * 0.45;

        double angle = random.method_43058() * Math.PI * 2;
        double speed = 0.01 + random.method_43058() * 0.025;

        double dx = Math.cos(angle) * speed;
        double dy = 0.04 + random.method_43058() * 0.05;
        double dz = Math.sin(angle) * speed;

        TClientParticles.spawn(
                ModParticles.SOUL_SPARK.get(),
                x + ox, y + oy, z + oz,
                dx, dy, dz
        );
    }
}