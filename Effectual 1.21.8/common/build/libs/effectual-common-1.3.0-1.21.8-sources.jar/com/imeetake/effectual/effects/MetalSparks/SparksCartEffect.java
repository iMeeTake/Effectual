package com.imeetake.effectual.effects.MetalSparks;

import com.imeetake.effectual.EffectualConfig;
import com.imeetake.effectual.ModParticles;
import com.imeetake.tlib.client.particle.TClientParticles;
import dev.architectury.event.events.client.ClientTickEvent;
import net.minecraft.class_1688;
import net.minecraft.class_243;
import net.minecraft.class_310;
import net.minecraft.class_5819;
import net.minecraft.class_638;

public class SparksCartEffect {

    private static final class_5819 RAND = class_5819.method_43047();

    public static void register() {
        ClientTickEvent.CLIENT_POST.register(client -> {
            if (!EffectualConfig.get().minecartSparks || client.field_1687 == null || client.field_1724 == null || client.method_1493())
                return;
            class_638 level = client.field_1687;

            level.method_18112().forEach(e -> {
                if (e instanceof class_1688 cart) spark(client, cart);
            });
        });
    }

    private static void spark(class_310 client, class_1688 cart) {
        class_243 vel = cart.method_18798();
        if (vel.method_37267() < 0.4) return;
        if (RAND.method_43057() > 0.1f) return;

        double y = cart.method_23318() + 0.1;
        double len = 0.7;
        double wid = 1.15;

        for (int side = -1; side <= 1; side += 2) {
            double x = cart.method_23317() + side * wid / 2;
            double z = cart.method_23321() + RAND.method_43058() * len - len / 2;

            TClientParticles.spawn(
                    ModParticles.METAL_SPARK.get(),
                    x, y, z,
                    vel.field_1352 * 0.2, 0.01, vel.field_1350 * 0.2
            );
        }
    }
}