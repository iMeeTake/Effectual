package com.imeetake.effectual.effects.Sparks;

import com.imeetake.effectual.EffectualConfig;
import com.imeetake.effectual.ModParticles;
import com.imeetake.tlib.client.particle.TClientParticles;
import dev.architectury.event.events.client.ClientTickEvent;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2680;
import net.minecraft.class_2741;
import net.minecraft.class_310;
import net.minecraft.class_5819;

public class FurnaceSparksEffect {

    private static final class_5819 RAND = class_5819.method_43047();
    private static int tickCounter = 0;

    public static void register() {
        ClientTickEvent.CLIENT_POST.register(client -> {
            if (!EffectualConfig.get().furnaceSparks || client.field_1687 == null || client.field_1724 == null || client.method_1493())
                return;
            if (++tickCounter < 4) return;
            tickCounter = 0;
            spawnNearPlayer(client);
        });
    }

    private static void spawnNearPlayer(class_310 client) {
        class_2338 center = client.field_1724.method_24515();
        class_2338.class_2339 pos = new class_2338.class_2339();
        int radius = 6;

        for (int dx = -radius; dx <= radius; dx++) {
            for (int dy = -2; dy <= 2; dy++) {
                for (int dz = -radius; dz <= radius; dz++) {
                    pos.method_10103(center.method_10263() + dx, center.method_10264() + dy, center.method_10260() + dz);
                    class_2680 state = client.field_1687.method_8320(pos);

                    boolean isFurnace = state.method_27852(class_2246.field_10181);
                    boolean isBlast = state.method_27852(class_2246.field_16333);
                    if (!isFurnace && !isBlast) continue;

                    if (!state.method_28500(class_2741.field_12548).orElse(false)) continue;
                    if (RAND.method_43057() > 0.45f) continue;

                    if (!state.method_28498(class_2741.field_12481)) continue;
                    class_2350 facing = state.method_11654(class_2741.field_12481);

                    spawnFrontSparks(pos, facing);
                }
            }
        }
    }

    private static void spawnFrontSparks(class_2338 pos, class_2350 facing) {
        double cx = pos.method_10263() + 0.5;
        double cz = pos.method_10260() + 0.5;

        double nx = facing.method_10148();
        double nz = facing.method_10165();

        double tx = nz;
        double tz = -nx;

        double cy = pos.method_10264() + 0.25 + RAND.method_43058() * 0.2;

        double px = cx + nx * 0.52;
        double pz = cz + nz * 0.52;

        double lateral = (RAND.method_43058() - 0.5) * 0.25;
        px += tx * lateral;
        pz += tz * lateral;

        double outSpeed = 0.008 + RAND.method_43058() * 0.012;
        double upSpeed = 0.015 + RAND.method_43058() * 0.02;
        double sideSpeed = (RAND.method_43058() - 0.5) * 0.008;

        double vx = nx * outSpeed + tx * sideSpeed;
        double vz = nz * outSpeed + tz * sideSpeed;

        TClientParticles.spawn(ModParticles.SPARK.get(), px, cy, pz, vx, upSpeed, vz);
    }
}