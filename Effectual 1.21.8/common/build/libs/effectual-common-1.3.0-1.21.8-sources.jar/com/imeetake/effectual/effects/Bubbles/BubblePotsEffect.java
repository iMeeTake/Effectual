package com.imeetake.effectual.effects.Bubbles;

import com.imeetake.effectual.EffectualConfig;
import com.imeetake.tlib.client.particle.TClientParticles;
import dev.architectury.event.events.client.ClientTickEvent;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_2398;
import net.minecraft.class_5819;
import net.minecraft.class_638;

public class BubblePotsEffect {
    private static final class_5819 RAND = class_5819.method_43047();
    private static final int RADIUS = 5;
    private static final int SAMPLES_PER_TICK = 48;

    public static void register() {
        ClientTickEvent.CLIENT_POST.register(client -> {
            if (!EffectualConfig.get().bubblePots || client.field_1687 == null || client.method_1493()) return;
            if (client.field_1724 == null) return;

            class_638 level = client.field_1687;
            class_2338 center = client.field_1724.method_24515();
            class_2338.class_2339 pos = new class_2338.class_2339();

            for (int i = 0; i < SAMPLES_PER_TICK; i++) {
                int dx = RAND.method_43048(RADIUS * 2 + 1) - RADIUS;
                int dy = RAND.method_43048(RADIUS * 2 + 1) - RADIUS;
                int dz = RAND.method_43048(RADIUS * 2 + 1) - RADIUS;

                pos.method_10103(center.method_10263() + dx, center.method_10264() + dy, center.method_10260() + dz);

                if (!level.method_8316(pos).method_15771()) continue;
                if (!level.method_8320(pos).method_27852(class_2246.field_42752)) continue;

                TClientParticles.spawn(
                        class_2398.field_11247,
                        pos.method_10263() + 0.5,
                        pos.method_10264() + 1.1,
                        pos.method_10260() + 0.5,
                        0, 0.1, 0
                );
            }
        });
    }
}