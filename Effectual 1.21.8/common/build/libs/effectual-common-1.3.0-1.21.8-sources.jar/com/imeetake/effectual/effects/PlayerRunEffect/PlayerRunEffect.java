package com.imeetake.effectual.effects.PlayerRunEffect;

import com.imeetake.effectual.EffectualConfig;
import com.imeetake.effectual.ModParticles;
import com.imeetake.tlib.client.particle.TClientParticles;
import dev.architectury.event.events.client.ClientTickEvent;
import net.minecraft.class_1657;
import net.minecraft.class_1937;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2400;
import net.minecraft.class_243;
import net.minecraft.class_2680;
import net.minecraft.class_2741;
import net.minecraft.class_310;
import net.minecraft.class_5819;

public class PlayerRunEffect {

    public static void register() {
        ClientTickEvent.CLIENT_POST.register(client -> {
            if (!EffectualConfig.get().runDust || client.field_1687 == null || client.method_1493()) return;

            for (class_1657 player : client.field_1687.method_18456()) {
                if (shouldPlayEffect(player)) {
                    spawnDust(client, player);
                }
            }
        });
    }

    private static boolean shouldPlayEffect(class_1657 player) {
        return player.method_5624()
                && !player.method_5715()
                && player.method_24828()
                && !player.method_5869()
                && !player.method_5799()
                && !player.method_7325();
    }

    private static void spawnDust(class_310 client, class_1657 player) {
        class_1937 level = client.field_1687;
        class_2338 pos = player.method_24515();

        class_2680 atFeet = level.method_8320(pos);
        class_2680 below = level.method_8320(pos.method_10074());

        class_243 velocity = player.method_18798();
        double speedFactor = 0.5;
        double vx = -velocity.field_1352 * speedFactor;
        double vz = -velocity.field_1350 * speedFactor;

        if (atFeet.method_27852(class_2246.field_10477) && atFeet.method_28498(class_2741.field_12536)) {
            spawnParticle(client, ModParticles.SNOW_DUST.get(), player, vx, vz, 0.1);
            return;
        }
        if (atFeet.method_27852(class_2246.field_37576) || atFeet.method_27852(class_2246.field_37547)) {
            spawnParticle(client, ModParticles.MUD_DUST.get(), player, vx, vz, 0.5);
            return;
        }

        class_2248 block = below.method_26204();
        if (block == class_2246.field_10102 || block == class_2246.field_42728) {
            spawnParticle(client, ModParticles.SAND_DUST.get(), player, vx, vz, 0.1);
        } else if (block == class_2246.field_10534) {
            spawnParticle(client, ModParticles.RED_SAND_DUST.get(), player, vx, vz, 0.1);
        } else if (block == class_2246.field_10477 || block == class_2246.field_10491 || block == class_2246.field_27879) {
            spawnParticle(client, ModParticles.SNOW_DUST.get(), player, vx, vz, 0.1);
        } else if (block == class_2246.field_10255 || block == class_2246.field_43227) {
            spawnParticle(client, ModParticles.GRAVEL_DUST.get(), player, vx, vz, 0.1);
        } else if (block == class_2246.field_37576 || block == class_2246.field_37556 || block == class_2246.field_37547) {
            spawnParticle(client, ModParticles.MUD_DUST.get(), player, vx, vz, 0.1);
        }
    }

    private static void spawnParticle(class_310 client, class_2400 type, class_1657 player, double vx, double vz, double yOffset) {
        class_5819 rand = client.field_1687.field_9229;

        double x = player.method_23317() + (rand.method_43058() - 0.5) * 0.6;
        double y = player.method_23318() + yOffset;
        double z = player.method_23321() + (rand.method_43058() - 0.5) * 0.6;

        double noisyVx = vx + (rand.method_43058() - 0.5) * 0.15;
        double noisyVz = vz + (rand.method_43058() - 0.5) * 0.15;

        TClientParticles.spawn(
                type,
                x, y, z,
                noisyVx, 0, noisyVz);
    }
}