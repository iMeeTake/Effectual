package com.imeetake.effectual.effects.WitherDecay;

import com.imeetake.effectual.EffectualConfig;
import com.imeetake.tlib.client.particle.TClientParticles;
import dev.architectury.event.events.client.ClientTickEvent;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import net.minecraft.class_1294;
import net.minecraft.class_1657;
import net.minecraft.class_2398;
import net.minecraft.class_5819;

public class WitherDecayEffect {
    private static final class_5819 RANDOM = class_5819.method_43047();
    private static final Map<UUID, Integer> tickCounters = new HashMap<>();

    public static void register() {
        ClientTickEvent.CLIENT_POST.register(client -> {
            if (!EffectualConfig.get().witherDecay || client.field_1687 == null || client.method_1493()) return;

            for (class_1657 player : client.field_1687.method_18456()) {
                UUID id = player.method_5667();

                if (!player.method_6059(class_1294.field_5920)) {
                    tickCounters.remove(id);
                    continue;
                }

                int count = tickCounters.getOrDefault(id, 0) + 1;
                if (count >= 3) {
                    tickCounters.put(id, 0);
                    spawn(player);
                } else {
                    tickCounters.put(id, count);
                }
            }
        });
    }

    private static void spawn(class_1657 player) {
        double x = player.method_23317() + (RANDOM.method_43058() - 0.5) * 1.2;
        double y = player.method_23318() + 0.3 + RANDOM.method_43058() * 1.5;
        double z = player.method_23321() + (RANDOM.method_43058() - 0.5) * 1.2;
        double dy = -0.015 - RANDOM.method_43058() * 0.01;

        TClientParticles.spawn(class_2398.field_11251, x, y, z, 0, dy, 0);
    }
}