package com.imeetake.effectual.effects.WaterDrip;

import net.minecraft.class_1657;
import net.minecraft.class_2400;
import net.minecraft.class_4002;
import net.minecraft.class_638;
import net.minecraft.class_703;
import net.minecraft.class_707;
import org.jetbrains.annotations.Nullable;

public class WaterDripParticleFactory implements class_707<class_2400> {
    private final class_4002 spriteSet;

    public WaterDripParticleFactory(class_4002 spriteSet) {
        this.spriteSet = spriteSet;
    }

    @Nullable
    @Override
    public class_703 createParticle(class_2400 type, class_638 level, double x, double y, double z, double dx, double dy, double dz) {
        class_1657 player = level.method_18459(x, y, z, 1.2, false);
        if (player == null) return null;

        float yaw = player.method_36454();
        double ry = Math.toRadians(yaw);
        double ox = x - player.method_23317();
        double oz = z - player.method_23321();

        double lx = ox * Math.cos(ry) + oz * Math.sin(ry);
        double lz = -ox * Math.sin(ry) + oz * Math.cos(ry);
        double ly = y - player.method_23318();

        return new WaterDripParticle(level, player, lx, ly, lz, this.spriteSet);
    }
}