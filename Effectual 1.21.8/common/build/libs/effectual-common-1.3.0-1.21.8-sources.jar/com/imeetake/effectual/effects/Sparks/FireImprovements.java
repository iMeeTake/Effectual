package com.imeetake.effectual.effects.Sparks;

import com.imeetake.effectual.EffectualConfig;
import com.imeetake.effectual.ModParticles;
import com.imeetake.tlib.client.particle.TClientParticles;
import dev.architectury.event.events.client.ClientTickEvent;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2680;
import net.minecraft.class_310;
import net.minecraft.class_5819;

public class FireImprovements {

    private static final class_5819 RAND = class_5819.method_43047();
    private static int tickCounter = 0;

    public static void register() {
        ClientTickEvent.CLIENT_POST.register(client -> {
            if (client.field_1687 == null || client.field_1724 == null || client.method_1493()) return;
            if (!EffectualConfig.get().fireImprovements) return;
            if (++tickCounter < 3) return;
            tickCounter = 0;
            spawn(client);
        });
    }

    private static void spawn(class_310 client) {
        class_2338 center = client.field_1724.method_24515();
        class_2338.class_2339 pos = new class_2338.class_2339();

        for (int dx = -8; dx <= 8; dx++) {
            for (int dy = -8; dy <= 8; dy++) {
                for (int dz = -8; dz <= 8; dz++) {
                    pos.method_10103(center.method_10263() + dx, center.method_10264() + dy, center.method_10260() + dz);
                    class_2680 state = client.field_1687.method_8320(pos);

                    if (!state.method_27852(class_2246.field_10036)) continue;
                    if (RAND.method_43057() >= 0.65f) continue;

                    spark(client, pos);
                }
            }
        }
    }

    private static void spark(class_310 client, class_2338 pos) {
        class_2350 attachedFace = getFireAttachmentFace(client, pos);

        double x, y, z;

        if (attachedFace == class_2350.field_11033) {
            x = pos.method_10263() + RAND.method_43058();
            y = pos.method_10264() + 0.4 + RAND.method_43058() * 0.5;
            z = pos.method_10260() + RAND.method_43058();
        } else {
            x = pos.method_10263() + 0.5;
            y = pos.method_10264() + 0.3 + RAND.method_43058() * 0.5;
            z = pos.method_10260() + 0.5;

            double offset = 0.3 + RAND.method_43058() * 0.15;
            x += attachedFace.method_10148() * offset;
            z += attachedFace.method_10165() * offset;

            double perpX = attachedFace.method_10165();
            double perpZ = -attachedFace.method_10148();
            double lateral = (RAND.method_43058() - 0.5) * 0.6;
            x += perpX * lateral;
            z += perpZ * lateral;
        }

        double angle = RAND.method_43058() * Math.PI * 2;
        double speed = 0.01 + RAND.method_43058() * 0.03;

        double dx = Math.cos(angle) * speed;
        double dy = 0.04 + RAND.method_43058() * 0.06;
        double dz = Math.sin(angle) * speed;

        TClientParticles.spawn(ModParticles.SPARK.get(), x, y, z, dx, dy, dz);
    }

    private static class_2350 getFireAttachmentFace(class_310 client, class_2338 firePos) {
        class_2338 below = firePos.method_10074();
        if (client.field_1687.method_8320(below).method_26216()) {
            return class_2350.field_11033;
        }

        for (class_2350 dir : class_2350.class_2353.field_11062) {
            class_2338 adjacent = firePos.method_10093(dir);
            if (client.field_1687.method_8320(adjacent).method_26216()) {
                return dir;
            }
        }

        return class_2350.field_11033;
    }
}