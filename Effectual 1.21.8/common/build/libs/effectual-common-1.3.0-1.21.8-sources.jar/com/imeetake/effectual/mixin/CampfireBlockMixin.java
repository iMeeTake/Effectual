package com.imeetake.effectual.mixin;

import com.imeetake.effectual.effects.Sparks.CampfireImprovements;
import com.imeetake.effectual.effects.SparksSoul.SoulCampfireImprovements;
import net.minecraft.class_1937;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_3922;
import net.minecraft.class_5819;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_3922.class)
public class CampfireBlockMixin {

    @Inject(method = "animateTick", at = @At("TAIL"))
    private void effectual$onAnimateTick(class_2680 state, class_1937 level, class_2338 pos, class_5819 random, CallbackInfo ci) {
        if (!state.method_11654(class_3922.field_17352)) return;

        if (state.method_27852(class_2246.field_23860)) {
            SoulCampfireImprovements.animateTick(level, pos, random);
        } else {
            CampfireImprovements.animateTick(level, pos, random);
        }
    }
}