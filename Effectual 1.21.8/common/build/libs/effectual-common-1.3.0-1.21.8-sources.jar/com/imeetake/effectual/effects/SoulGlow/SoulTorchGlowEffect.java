package com.imeetake.effectual.effects.SoulGlow;

import com.imeetake.effectual.EffectualConfig;
import com.imeetake.effectual.ModParticles;
import com.imeetake.tlib.client.particle.TClientParticles;
import dev.architectury.event.events.client.ClientTickEvent;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2680;
import net.minecraft.class_2741;
import net.minecraft.class_310;
import net.minecraft.class_5819;

public class SoulTorchGlowEffect {
    private static final class_5819 RAND = class_5819.method_43047();
    private static final int SAMPLES_PER_TICK = 100;
    private static final int RADIUS = 6;

    public static void register() {
        ClientTickEvent.CLIENT_POST.register(client -> {
            if (!EffectualConfig.get().torchImprovements
                    || client.field_1687 == null
                    || client.field_1724 == null
                    || client.method_1493())
                return;

            spawnNearPlayer(client);
        });
    }

    private static void spawnNearPlayer(class_310 client) {
        class_2338 center = client.field_1724.method_24515();
        class_2338.class_2339 pos = new class_2338.class_2339();

        int startX = center.method_10263();
        int startY = center.method_10264();
        int startZ = center.method_10260();

        for (int i = 0; i < SAMPLES_PER_TICK; i++) {
            int dx = RAND.method_43048(RADIUS * 2 + 1) - RADIUS;
            int dy = RAND.method_43048(5) - 2;
            int dz = RAND.method_43048(RADIUS * 2 + 1) - RADIUS;

            pos.method_10103(startX + dx, startY + dy, startZ + dz);

            class_2680 state = client.field_1687.method_8320(pos);

            boolean isFloor = state.method_27852(class_2246.field_22092);
            boolean isWall = state.method_27852(class_2246.field_22093);

            if (!isFloor && !isWall) continue;

            glow(pos, state, isFloor);
        }
    }

    private static void glow(class_2338 pos, class_2680 state, boolean isFloor) {
        double x, y, z;

        if (isFloor) {
            x = pos.method_10263() + 0.5 + (RAND.method_43058() - 0.5) * 0.1;
            y = pos.method_10264() + 0.65;
            z = pos.method_10260() + 0.5 + (RAND.method_43058() - 0.5) * 0.1;
        } else {
            class_2350 f = state.method_11654(class_2741.field_12481);
            class_2350 opposite = f.method_10153();

            double offset = 0.27;
            x = pos.method_10263() + 0.5 + (opposite.method_10148() * offset) + (RAND.method_43058() - 0.5) * 0.1;
            y = pos.method_10264() + 0.65;
            z = pos.method_10260() + 0.5 + (opposite.method_10165() * offset) + (RAND.method_43058() - 0.5) * 0.1;
        }

        TClientParticles.spawn(
                ModParticles.SOUL_GLOW.get(),
                x, y, z,
                0, -0.002, 0
        );
    }
}