package com.imeetake.effectual.effects.MouthSteam;

import net.minecraft.class_1657;
import net.minecraft.class_2400;
import net.minecraft.class_4002;
import net.minecraft.class_638;
import net.minecraft.class_703;
import net.minecraft.class_707;
import org.jetbrains.annotations.Nullable;

public class MouthSteamParticleFactory implements class_707<class_2400> {
    private final class_4002 spriteSet;

    public MouthSteamParticleFactory(class_4002 spriteSet) {
        this.spriteSet = spriteSet;
    }

    @Nullable
    @Override
    public class_703 createParticle(class_2400 type, class_638 level, double x, double y, double z, double dx, double dy, double dz) {
        class_1657 player = level.method_18459(x, y, z, 4.0, false);

        if (player == null) {
            return null;
        }

        return new MouthSteamParticle(level, player, spriteSet);
    }
}