package com.imeetake.effectual.effects.StripEffect;

import com.imeetake.effectual.EffectualConfig;
import com.imeetake.tlib.client.particle.TClientParticles;
import dev.architectury.event.EventResult;
import dev.architectury.event.events.client.ClientTickEvent;
import dev.architectury.event.events.common.InteractionEvent;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;
import net.minecraft.class_1269;
import net.minecraft.class_1743;
import net.minecraft.class_1799;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2388;
import net.minecraft.class_2398;
import net.minecraft.class_2680;
import net.minecraft.class_310;
import net.minecraft.class_3481;
import net.minecraft.class_5819;
import net.minecraft.class_638;

public class StripEffect {

    private static final class_5819 RAND = class_5819.method_43047();

    private record Pending(class_2680 oldState, class_2350 face, long expiresAt) {
    }

    private static final Map<class_2338, Pending> PENDING = new HashMap<>();

    public static void register() {
        InteractionEvent.RIGHT_CLICK_BLOCK.register((player, hand, pos, face) -> {
            if (!EffectualConfig.get().stripEffect) return class_1269.field_5811;
            if (!player.method_37908().field_9236) return class_1269.field_5811;

            class_1799 stack = player.method_5998(hand);
            if (!(stack.method_7909() instanceof class_1743)) return class_1269.field_5811;

            class_2680 state = player.method_37908().method_8320(pos);
            if (!isLog(state)) return class_1269.field_5811;

            long now = player.method_37908().method_8510();
            PENDING.put(pos.method_10062(), new Pending(state, face, now + 6L));
            return class_1269.field_5811;
        });

        ClientTickEvent.CLIENT_POST.register(client -> {
            if (!EffectualConfig.get().stripEffect || client.field_1687 == null || client.method_1493()) return;
            tick(client);
        });
    }

    private static void tick(class_310 client) {
        class_638 level = client.field_1687;
        long now = level.method_8510();

        Iterator<Map.Entry<class_2338, Pending>> it = PENDING.entrySet().iterator();
        while (it.hasNext()) {
            var e = it.next();
            class_2338 pos = e.getKey();
            Pending p = e.getValue();

            if (now >= p.expiresAt()) {
                it.remove();
                continue;
            }

            class_2680 cur = level.method_8320(pos);
            if (cur.method_26204() == p.oldState().method_26204()) continue;

            if (isLog(p.oldState()) && isLog(cur)) {
                spawnParticles(pos, p.oldState(), p.face());
            }

            it.remove();
        }
    }

    private static boolean isLog(class_2680 state) {
        return state.method_26164(class_3481.field_15475);
    }

    private static void spawnParticles(class_2338 pos, class_2680 state, class_2350 face) {
        double nx = face.method_10148();
        double ny = face.method_10164();
        double nz = face.method_10165();

        double cx = pos.method_10263() + 0.5 + nx * 0.51;
        double cy = pos.method_10264() + 0.5 + ny * 0.51;
        double cz = pos.method_10260() + 0.5 + nz * 0.51;

        int chips = 7 + RAND.method_43048(4);
        for (int i = 0; i < chips; i++) {
            double t = (RAND.method_43058() - 0.5) * 0.16;
            double sx = nx == 0 ? t : 0;
            double sy = ny == 0 ? t : 0;
            double sz = nz == 0 ? t : 0;
            double vx = nx * (0.04 + RAND.method_43058() * 0.03);
            double vy = ny * (0.04 + RAND.method_43058() * 0.03);
            double vz = nz * (0.04 + RAND.method_43058() * 0.03);

            TClientParticles.spawn(
                    new class_2388(class_2398.field_11217, state),
                    cx + sx, cy + sy, cz + sz,
                    vx, vy, vz
            );
        }
    }
}