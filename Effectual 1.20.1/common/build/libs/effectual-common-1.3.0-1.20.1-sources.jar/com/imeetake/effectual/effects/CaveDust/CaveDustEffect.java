package com.imeetake.effectual.effects.CaveDust;

import com.imeetake.effectual.EffectualConfig;
import com.imeetake.tlib.client.particle.TClientParticles;
import dev.architectury.event.events.client.ClientTickEvent;
import net.minecraft.class_1944;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2398;
import net.minecraft.class_2680;
import net.minecraft.class_310;
import net.minecraft.class_3481;
import net.minecraft.class_5819;

public class CaveDustEffect {

    private static final class_5819 RAND = class_5819.method_43047();
    private static boolean inCaveCached = false;
    private static int checkTimer = 0;

    public static void register() {
        ClientTickEvent.CLIENT_POST.register(client -> {
            if (!EffectualConfig.get().caveDust) return;
            if (client.field_1724 == null || client.field_1687 == null || client.method_1493()) return;

            if (checkTimer++ >= 20) {
                checkTimer = 0;
                updateCaveStatus(client);
            }

            if (!inCaveCached) return;

            spawnDustParticles(client);
        });
    }

    private static void updateCaveStatus(class_310 client) {
        class_2338 center = client.field_1724.method_24515();

        if (client.field_1687.method_8314(class_1944.field_9284, center) > 0) {
            inCaveCached = false;
            return;
        }

        if (client.field_1687.method_8311(center.method_10084())) {
            inCaveCached = false;
            return;
        }

        int radius = 6;
        int naturalCount = 0;
        int artificialCount = 0;

        class_2338.class_2339 mpos = new class_2338.class_2339();

        for (int dx = -radius; dx <= radius; dx++) {
            for (int dy = -radius; dy <= radius; dy++) {
                for (int dz = -radius; dz <= radius; dz++) {
                    mpos.method_10103(center.method_10263() + dx, center.method_10264() + dy, center.method_10260() + dz);
                    class_2680 state = client.field_1687.method_8320(mpos);

                    if (state.method_26215()) continue;

                    if (isNaturalBlock(state)) {
                        naturalCount++;
                    } else if (isArtificialBlock(state)) {
                        artificialCount++;
                    }
                }
            }
        }

        int total = naturalCount + artificialCount;
        if (total == 0) {
            inCaveCached = false;
            return;
        }

        float naturalRatio = (float) naturalCount / total;
        inCaveCached = naturalRatio >= 0.85f;
    }

    private static boolean isNaturalBlock(class_2680 state) {
        if (state.method_26164(class_3481.field_25806)) return true;
        if (state.method_26164(class_3481.field_29822)) return true;
        if (state.method_26164(class_3481.field_29193)) return true;
        if (state.method_26164(class_3481.field_28988)) return true;
        if (state.method_26164(class_3481.field_29195)) return true;
        if (state.method_26164(class_3481.field_23062)) return true;
        if (state.method_26164(class_3481.field_28990)) return true;
        if (state.method_26164(class_3481.field_28991)) return true;
        if (state.method_26164(class_3481.field_28989)) return true;
        if (state.method_26164(class_3481.field_29194)) return true;

        class_2248 b = state.method_26204();
        return b == class_2246.field_10255
                || b == class_2246.field_10460
                || b == class_2246.field_10102
                || b == class_2246.field_10534
                || b == class_2246.field_28048
                || b == class_2246.field_28049
                || b == class_2246.field_27114
                || b == class_2246.field_27165
                || b == class_2246.field_27159
                || b == class_2246.field_27160
                || b == class_2246.field_28681
                || b == class_2246.field_28680
                || b == class_2246.field_28411
                || b == class_2246.field_37568
                || b == class_2246.field_37569
                || b == class_2246.field_37570
                || b == class_2246.field_28108
                || b == class_2246.field_37571
                || b == class_2246.field_10382
                || b == class_2246.field_10164;
    }

    private static boolean isArtificialBlock(class_2680 state) {
        if (state.method_26164(class_3481.field_15471)) return true;
        if (state.method_26164(class_3481.field_15481)) return true;
        if (state.method_26164(class_3481.field_15479)) return true;
        if (state.method_26164(class_3481.field_16443)) return true;
        if (state.method_26164(class_3481.field_15495)) return true;
        if (state.method_26164(class_3481.field_15487)) return true;
        if (state.method_26164(class_3481.field_16584)) return true;
        if (state.method_26164(class_3481.field_15504)) return true;
        if (state.method_26164(class_3481.field_15459)) return true;
        if (state.method_26164(class_3481.field_15469)) return true;
        if (state.method_26164(class_3481.field_15463)) return true;
        if (state.method_26164(class_3481.field_15500)) return true;
        if (state.method_26164(class_3481.field_15501)) return true;
        if (state.method_26164(class_3481.field_36265)) return true;
        if (state.method_26164(class_3481.field_26983)) return true;
        if (state.method_26164(class_3481.field_23799)) return true;
        if (state.method_26164(class_3481.field_15486)) return true;
        if (state.method_26164(class_3481.field_21490)) return true;

        class_2248 b = state.method_26204();
        return b == class_2246.field_10445
                || b == class_2246.field_29031
                || b == class_2246.field_9989
                || b == class_2246.field_10056
                || b == class_2246.field_10065
                || b == class_2246.field_10416
                || b == class_2246.field_10552
                || b == class_2246.field_10360
                || b == class_2246.field_10093
                || b == class_2246.field_10346
                || b == class_2246.field_10289
                || b == class_2246.field_28892
                || b == class_2246.field_28900
                || b == class_2246.field_28896
                || b == class_2246.field_28904
                || b == class_2246.field_10104
                || b == class_2246.field_10033
                || b == class_2246.field_10285
                || b == class_2246.field_27115
                || b == class_2246.field_10576
                || b == class_2246.field_23985
                || b == class_2246.field_10336
                || b == class_2246.field_10099
                || b == class_2246.field_22092
                || b == class_2246.field_22093
                || b == class_2246.field_16541
                || b == class_2246.field_22110
                || b == class_2246.field_9980
                || b == class_2246.field_10181
                || b == class_2246.field_16333
                || b == class_2246.field_16334
                || b == class_2246.field_10034
                || b == class_2246.field_10380
                || b == class_2246.field_16328
                || b == class_2246.field_10504
                || b == class_2246.field_40276
                || b == class_2246.field_16330
                || b == class_2246.field_10485
                || b == class_2246.field_10333
                || b == class_2246.field_10312
                || b == class_2246.field_10228
                || b == class_2246.field_10200
                || b == class_2246.field_9983
                || b == class_2246.field_16492;
    }

    private static void spawnDustParticles(class_310 client) {
        int frequency = EffectualConfig.get().caveDustFrequency;
        if (frequency <= 0 || RAND.method_43048(10) > frequency) return;

        class_2338 center = client.field_1724.method_24515();

        for (int i = 0; i < 2; i++) {
            double x = center.method_10263() + (RAND.method_43058() - 0.5) * 32.0;
            double z = center.method_10260() + (RAND.method_43058() - 0.5) * 32.0;
            double y = center.method_10264() + RAND.method_43058() * 6.0 + 1.0;

            class_2338 pos = class_2338.method_49637(x, y, z);

            if (!client.field_1687.method_8320(pos).method_26215()) continue;
            if (!client.field_1687.method_8320(pos.method_10074()).method_26215()) continue;

            TClientParticles.spawn(class_2398.field_23956,
                    x, y, z,
                    0, -0.01, 0);
        }
    }
}