package com.imeetake.effectual.mixin;

import com.imeetake.effectual.EffectualConfig;
import com.imeetake.effectual.ModParticles;
import com.imeetake.tlib.client.particle.TClientParticles;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_239;
import net.minecraft.class_243;
import net.minecraft.class_2680;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_3965;
import net.minecraft.class_5819;
import net.minecraft.class_636;
import net.minecraft.class_638;
import net.minecraft.class_6862;
import net.minecraft.class_746;
import net.minecraft.class_7924;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_636.class)
public class MetalHitMixin {

    @Inject(method = "startDestroyBlock", at = @At("HEAD"))
    private void onMetalHit(class_2338 pos, class_2350 direction, CallbackInfoReturnable<Boolean> cir) {
        if (!EffectualConfig.get().metalHitSparks) return;

        class_310 client = class_310.method_1551();
        if (client.field_1687 == null || client.field_1724 == null) return;

        class_638 world = client.field_1687;
        class_746 player = client.field_1724;

        class_1799 mainHandItem = player.method_6047();

        class_6862<class_1792> metalItemsTag = class_6862.method_40092(class_7924.field_41197, new class_2960("effectual", "metal_items"));
        if (!mainHandItem.method_31573(metalItemsTag)) return;

        class_2680 blockState = world.method_8320(pos);
        class_6862<class_2248> metalBlocksTag = class_6862.method_40092(class_7924.field_41254, new class_2960("effectual", "metal_blocks"));
        if (!blockState.method_26164(metalBlocksTag)) return;

        class_243 hitPos;
        class_239 hitResult = client.field_1765;

        if (hitResult instanceof class_3965 blockHitResult && blockHitResult.method_17777().equals(pos)) {
            hitPos = blockHitResult.method_17784();
        } else {
            hitPos = class_243.method_24953(pos).method_1031(
                    direction.method_10148() * 0.5,
                    direction.method_10164() * 0.5,
                    direction.method_10165() * 0.5
            );
        }

        spawnSparks(world, hitPos, direction);
    }

    private void spawnSparks(class_638 world, class_243 pos, class_2350 direction) {
        class_5819 random = world.field_9229;

        for (int i = 0; i < 6 + random.method_43048(4); i++) {
            double offsetX = pos.field_1352 + (random.method_43058() - 0.5) * 0.2;
            double offsetY = pos.field_1351 + (random.method_43058() - 0.5) * 0.2;
            double offsetZ = pos.field_1350 + (random.method_43058() - 0.5) * 0.2;

            double velocityX = (random.method_43058() - 0.5) * 0.1 + direction.method_10148() * 0.1;
            double velocityY = (random.method_43058() - 0.5) * 0.1 + direction.method_10164() * 0.1;
            double velocityZ = (random.method_43058() - 0.5) * 0.1 + direction.method_10165() * 0.1;

            TClientParticles.spawn(ModParticles.METAL_SPARK.get(), offsetX, offsetY, offsetZ, velocityX, velocityY, velocityZ);
        }
    }
}