package com.imeetake.effectual.effects.SoulGlow;

import com.imeetake.tlib.client.particle.TOrientedParticle;
import net.minecraft.class_1058;
import net.minecraft.class_2400;
import net.minecraft.class_243;
import net.minecraft.class_3532;
import net.minecraft.class_4002;
import net.minecraft.class_4184;
import net.minecraft.class_4588;
import net.minecraft.class_638;

public class SoulGlowParticle extends TOrientedParticle<class_2400> {
    private final class_243 home;
    private class_243 initialVelocity;
    private class_243 forward;
    private final double seedA;
    private final double seedB;

    protected double prevPosX, prevPosY, prevPosZ;

    public SoulGlowParticle(class_638 level,
                            double x, double y, double z,
                            double velocityX, double velocityY, double velocityZ,
                            class_4002 spriteSet) {
        super(level, x, y, z, velocityX, velocityY, velocityZ, spriteSet);

        this.scale = 0.028f + field_3840.method_43057() * 0.010f;
        this.field_3847 = 52 + field_3840.method_43048(18);
        this.field_3841 = 0.0F;

        float base = 0.9f + field_3840.method_43057() * 0.1f;
        float r = base * (0.05f + field_3840.method_43057() * 0.05f);
        float g = base * (0.70f + field_3840.method_43057() * 0.15f);
        float b = base * (0.95f + field_3840.method_43057() * 0.05f);
        this.method_3084(r, g, b);

        this.field_3862 = false;
        this.field_3844 = 0.0F;

        this.home = new class_243(x, y, z);
        this.initialVelocity = new class_243(velocityX, velocityY, velocityZ);
        this.forward = this.initialVelocity.method_1027() > 1.0E-6 ? this.initialVelocity.method_1029() : new class_243(0, 1, 0);

        this.seedA = field_3840.method_43058() * 1000.0;
        this.seedB = field_3840.method_43058() * 1000.0;
        this.prevPosX = this.field_3874;
        this.prevPosY = this.field_3854;
        this.prevPosZ = this.field_3871;
    }

    @Override
    public void method_3070() {
        this.prevPosX = this.field_3874;
        this.prevPosY = this.field_3854;
        this.prevPosZ = this.field_3871;

        double t = (this.field_3866 + this.seedA) * 0.10;
        double lateralAmp = 0.00020 + 0.00010 * Math.sin((this.field_3866 + this.seedB) * 0.15);
        double ax = lateralAmp * Math.sin(t);
        double az = lateralAmp * Math.cos(t);
        double ay = 0.00065 + 0.00025 * Math.sin((this.field_3866 + this.seedB) * 0.22);

        class_243 toHome = this.home.method_1023(this.field_3874, this.field_3854, this.field_3871);
        class_243 toHomeXZ = new class_243(toHome.field_1352, 0.0, toHome.field_1350);
        double horizDist = Math.sqrt(toHomeXZ.field_1352 * toHomeXZ.field_1352 + toHomeXZ.field_1350 * toHomeXZ.field_1350);
        double leashK = 0.0030;
        if (horizDist > 0.35) leashK = 0.009;
        ax += toHomeXZ.field_1352 * leashK;
        az += toHomeXZ.field_1350 * leashK;

        this.field_3852 += ax;
        this.field_3850 += az;
        this.field_3869 += ay;

        double maxSpeed = 0.010;
        double vx = this.field_3852, vy = this.field_3869, vz = this.field_3850;
        double speed = Math.sqrt(vx * vx + vy * vy + vz * vz);
        if (speed > maxSpeed) {
            double k = maxSpeed / speed;
            this.field_3852 *= k;
            this.field_3869 *= k;
            this.field_3850 *= k;
        }

        this.field_3852 *= 0.986;
        this.field_3869 *= 0.986;
        this.field_3850 *= 0.986;

        class_243 v = new class_243(this.field_3852, this.field_3869, this.field_3850);
        if (v.method_1027() > 1.0E-7) this.forward = v.method_1029();

        float progress = (float) this.field_3866 / (float) this.field_3847;
        float aIn = smoothstep(0.00f, 0.15f, progress);
        float aOut = 1.0f - smoothstep(0.82f, 1.00f, progress);
        this.field_3841 = 0.80f * aIn * aOut;

        super.method_3070();
    }

    @Override
    public void buildGeometry(class_4588 vc, class_4184 camera, float tickDelta) {
        float px = (float) class_3532.method_16436(tickDelta, this.prevPosX, this.field_3874);
        float py = (float) class_3532.method_16436(tickDelta, this.prevPosY, this.field_3854);
        float pz = (float) class_3532.method_16436(tickDelta, this.prevPosZ, this.field_3871);
        class_243 cam = camera.method_19326();
        class_243 center = new class_243(px - cam.field_1352, py - cam.field_1351, pz - cam.field_1350);

        class_243 f = this.forward.method_1027() > 1.0E-7 ? this.forward : new class_243(0, 1, 0);
        class_243 upRef = Math.abs(f.field_1351) > 0.99 ? new class_243(0, 0, 1) : new class_243(0, 1, 0);
        class_243 right = f.method_1036(upRef).method_1029();
        class_243 up = right.method_1036(f).method_1029();

        float speed = (float) new class_243(this.field_3852, this.field_3869, this.field_3850).method_1033();
        float len = this.scale * (0.65f + speed * 5.5f);
        float halfW = this.scale * (0.22f + speed * 1.5f);

        class_243 tail = f.method_1021(-len * 0.5);
        class_243 nose = f.method_1021(len * 0.5);
        class_243 offRight = right.method_1021(halfW);
        class_243 offLeft = right.method_1021(-halfW);

        class_243 q1 = center.method_1019(nose).method_1019(offRight);
        class_243 q2 = center.method_1019(nose).method_1019(offLeft);
        class_243 q3 = center.method_1019(tail).method_1019(offLeft);
        class_243 q4 = center.method_1019(tail).method_1019(offRight);

        var sprite = this.spriteSet.method_18138(this.field_3866, this.field_3847);
        float u1 = sprite.method_4594();
        float u2 = sprite.method_4577();
        float v1 = sprite.method_4593();
        float v2 = sprite.method_4575();
        int light = this.method_3068(tickDelta);

        vertex(vc, q1, u2, v1, light);
        vertex(vc, q2, u1, v1, light);
        vertex(vc, q3, u1, v2, light);
        vertex(vc, q4, u2, v2, light);
    }

    private void vertex(class_4588 vc, class_243 pos, float u, float v, int light) {
        vc.method_22912(pos.field_1352, pos.field_1351, pos.field_1350)
                .method_22913(u, v)
                .method_22915(this.field_3861, this.field_3842, this.field_3859, this.field_3841)
                .method_22916(light)
                .method_1344();
    }

    private float smoothstep(float edge0, float edge1, float x) {
        float t = class_3532.method_15363((x - edge0) / (edge1 - edge0), 0.0f, 1.0f);
        return t * t * (3.0f - 2.0f * t);
    }
}