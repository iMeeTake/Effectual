package com.imeetake.effectual.effects.PlayerRunEffect.DustParticles;

import com.imeetake.effectual.effects.PlayerRunEffect.RunDustParticle;
import net.minecraft.class_1058;
import net.minecraft.class_2400;
import net.minecraft.class_4002;
import net.minecraft.class_5819;
import net.minecraft.class_638;
import net.minecraft.class_703;
import net.minecraft.class_707;
import org.jetbrains.annotations.Nullable;

public class SandDustParticle extends RunDustParticle {

    public SandDustParticle(class_638 level, double x, double y, double z, double vx, double vy, double vz, class_1058 sprite) {
        super(level, x, y, z, vx, vy, vz, Weight.LIGHT, 0.9F, 0.8F, 0.5F, sprite);
    }

    public static class Factory implements class_707<class_2400> {
        private final class_4002 spriteSet;

        public Factory(class_4002 spriteSet) {
            this.spriteSet = spriteSet;
        }

        @Nullable
        @Override
        public class_703 createParticle(class_2400 type, class_638 level, double x, double y, double z, double dx, double dy, double dz, class_5819 random) {
            return new SandDustParticle(level, x, y, z, dx, dy, dz, this.spriteSet.method_18139(random));
        }
    }
}