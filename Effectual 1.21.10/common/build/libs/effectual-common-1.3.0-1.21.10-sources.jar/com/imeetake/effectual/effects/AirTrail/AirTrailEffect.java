package com.imeetake.effectual.effects.AirTrail;

import com.imeetake.effectual.EffectualConfig;
import com.imeetake.effectual.ModParticles;
import com.imeetake.tlib.client.particle.TClientParticles;
import dev.architectury.event.events.client.ClientTickEvent;
import net.minecraft.class_1657;
import net.minecraft.class_243;
import net.minecraft.class_5819;

public class AirTrailEffect {
    private static final double MIN_SPEED_SQR = 0.55;
    private static final int SPAWN_INTERVAL = 4;
    private static final class_5819 RAND = class_5819.method_43047();
    private static int tickCounter = 0;

    public static void register() {
        ClientTickEvent.CLIENT_POST.register(client -> {
            if (!EffectualConfig.get().airTrail || client.field_1687 == null || client.method_1493()) return;
            if (client.field_1724 == null) return;

            tickCounter++;
            if (tickCounter < SPAWN_INTERVAL) return;
            tickCounter = 0;

            for (class_1657 player : client.field_1687.method_18456()) {
                if (!player.method_6128() || player.method_7325() || player.method_5767()) {
                    continue;
                }
                spawnAirTrail(player);
            }
        });
    }

    private static void spawnAirTrail(class_1657 player) {
        class_243 velocity = player.method_18798();
        if (velocity.method_1027() < MIN_SPEED_SQR) return;

        class_243 dir = velocity.method_1029();

        class_243 up = new class_243(0, 1, 0);
        class_243 side = dir.method_1036(up).method_1029();
        if (side.method_1027() < 0.001) {
            side = new class_243(1, 0, 0);
        }

        boolean leftSide = RAND.method_43056();
        double baseOffset = leftSide ? -1.0 : 1.0;
        double lateralVariation = (RAND.method_43058() - 0.5) * 0.4;
        double depthVariation = (RAND.method_43058() - 0.5) * 0.3;
        double heightVariation = (RAND.method_43058() - 0.5) * 0.25;

        class_243 pos = player.method_73189()
                .method_1031(0, player.method_5751() * 0.3 + heightVariation, 0)
                .method_1019(dir.method_1021(-0.25 + depthVariation))
                .method_1019(side.method_1021(baseOffset + lateralVariation));

        double speed = velocity.method_1033();
        double drag = 0.1 + RAND.method_43058() * 0.08;

        class_243 baseVel = dir.method_1021(-speed * drag);

        double noiseX = (RAND.method_43058() - 0.5) * 0.03;
        double noiseY = (RAND.method_43058() - 0.5) * 0.02;
        double noiseZ = (RAND.method_43058() - 0.5) * 0.03;

        TClientParticles.spawn(
                ModParticles.AIR_TRAIL.get(),
                pos.field_1352, pos.field_1351, pos.field_1350,
                baseVel.field_1352 + noiseX, baseVel.field_1351 + noiseY, baseVel.field_1350 + noiseZ
        );
    }
}