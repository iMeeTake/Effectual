package com.imeetake.effectual.effects.PlayerRunEffect;

import net.minecraft.class_1058;
import net.minecraft.class_3940;
import net.minecraft.class_638;

public abstract class RunDustParticle extends class_3940 {

    public enum Weight {
        LIGHT,
        HEAVY
    }

    protected final Weight weight;
    protected final float rotSpeed;
    protected float baseSize;

    protected RunDustParticle(class_638 level, double x, double y, double z, double vx, double vy, double vz,
                              Weight weight, float r, float g, float b, class_1058 sprite) {
        super(level, x, y, z, vx, vy, vz, sprite);

        this.weight = weight;

        float brightnessNoise = (field_3840.method_43057() - 0.5F) * 0.15F;

        this.field_62633 = Math.max(0.0F, Math.min(1.0F, r + brightnessNoise));
        this.field_62634 = Math.max(0.0F, Math.min(1.0F, g + brightnessNoise));
        this.field_62635 = Math.max(0.0F, Math.min(1.0F, b + brightnessNoise));

        this.baseSize = 0.04F * (1.0F + field_3840.method_43057() * 0.5F);
        this.field_17867 = this.baseSize;

        this.rotSpeed = (field_3840.method_43057() - 0.5F) * (weight == Weight.HEAVY ? 0.25F : 0.1F);
        this.field_62637 = field_3840.method_43057() * 6.28F;
        this.field_62638 = this.field_62637;

        if (weight == Weight.LIGHT) {
            this.field_3847 = 15 + this.field_3840.method_43048(10);
            this.field_3844 = 0.02F;
            this.field_62636 = 0.9F;

            this.field_3852 = vx;
            this.field_3869 = vy + 0.05;
            this.field_3850 = vz;
        } else {
            this.field_3847 = 25 + this.field_3840.method_43048(15);
            this.field_3844 = 0.5F;
            this.field_62636 = 1.0F;

            this.field_3852 = vx;
            this.field_3869 = vy + 0.1;
            this.field_3850 = vz;
        }
    }

    @Override
    public void method_3070() {
        this.field_3858 = this.field_3874;
        this.field_3838 = this.field_3854;
        this.field_3856 = this.field_3871;

        if (this.field_3866++ >= this.field_3847) {
            this.method_3085();
            return;
        }

        if (weight == Weight.LIGHT || !this.field_3845) {
            this.field_62638 = this.field_62637;
            this.field_62637 += this.rotSpeed;
        }

        if (weight == Weight.LIGHT) {
            if (this.field_3866 < 4) {
                this.baseSize += 0.004F;
                this.field_17867 = this.baseSize;
            }

            this.field_3869 -= 0.005D + this.field_3844;
            this.method_3069(this.field_3852, this.field_3869, this.field_3850);

            this.field_3852 *= 0.9;
            this.field_3869 *= 0.9;
            this.field_3850 *= 0.9;

            if (this.field_3845) {
                this.field_3852 *= 0.7;
                this.field_3850 *= 0.7;
            }

        } else {
            if (!this.field_3845) {
                this.field_3869 -= 0.04D;
            } else {
                this.field_3852 = 0;
                this.field_3850 = 0;
            }

            this.method_3069(this.field_3852, this.field_3869, this.field_3850);

            if (!this.field_3845) {
                this.field_3852 *= 0.95;
                this.field_3850 *= 0.95;
            }
        }
        int fadeTime = (weight == Weight.HEAVY) ? 10 : 7;

        if (this.field_3866 > this.field_3847 - fadeTime) {
            float fadeProgress = (float) (this.field_3866 - (this.field_3847 - fadeTime)) / (float) fadeTime;
            this.field_17867 = this.baseSize * (1.0F - fadeProgress);
        }
    }

    @Override
    protected class_11941 method_74255() {
        return class_11941.field_62641;
    }
}