package com.imeetake.effectual.effects.WaterDrip;

import net.minecraft.class_1058;
import net.minecraft.class_1657;
import net.minecraft.class_3940;
import net.minecraft.class_638;

public class WaterDripParticle extends class_3940 {
    private final class_1657 player;
    private final double localOffsetX;
    private final double localOffsetZ;
    private int stickTicks;
    private boolean released;

    public WaterDripParticle(class_638 level, class_1657 player, double localOffsetX, double localOffsetY, double localOffsetZ, class_1058 sprite) {
        super(level, player.method_23317(), player.method_23318() + localOffsetY, player.method_23321(), 0, 0, 0, sprite);
        this.player = player;
        this.localOffsetX = localOffsetX;
        this.localOffsetZ = localOffsetZ;

        this.field_17867 = 0.016F + field_3840.method_43057() * 0.012F;
        this.field_3847 = 20 + field_3840.method_43048(12);
        this.field_3844 = 0.038F;

        this.field_62636 = 0.45F + field_3840.method_43057() * 0.2F;
        this.method_74305(0.45F, 0.70F, 1.00F);

        this.stickTicks = 6 + field_3840.method_43048(4);
        this.released = false;
    }

    @Override
    public void method_3070() {
        super.method_3070();

        if (!released && this.field_3866 <= this.stickTicks) {
            double yaw = Math.toRadians(-this.player.method_36454());
            double cos = Math.cos(yaw);
            double sin = Math.sin(yaw);

            double ox = this.localOffsetX * cos - this.localOffsetZ * sin;
            double oz = this.localOffsetX * sin + this.localOffsetZ * cos;

            double slide = this.field_3844 * 0.4;
            double px = this.player.method_23317() + ox;
            double pz = this.player.method_23321() + oz;

            this.method_3063(px, this.field_3854 - slide, pz);
            this.field_3852 = 0;
            this.field_3869 = 0;
            this.field_3850 = 0;

            if (this.field_3866 == this.stickTicks) {
                this.released = true;
                this.field_3852 = this.player.method_18798().field_1352 * 0.25;
                this.field_3850 = this.player.method_18798().field_1350 * 0.25;
                this.field_3869 = -this.field_3844 * 0.5;
            }
        } else {
            this.field_3869 -= this.field_3844 * 0.6;
            this.field_3874 += this.field_3852;
            this.field_3854 += this.field_3869;
            this.field_3871 += this.field_3850;
            this.field_3852 *= 0.95;
            this.field_3850 *= 0.95;
            if (this.field_3869 < -0.16) this.field_3869 = -0.16;
        }

        float t = (float) this.field_3866 / (float) this.field_3847;
        float aIn = t < 0.25F ? t * 4F : 1F;
        float aOut = t > 0.75F ? Math.max(0F, (1F - t) / 0.25F) : 1F;
        this.field_62636 = (0.45F + 0.2F) * aIn * aOut;
    }

    @Override
    protected class_11941 method_74255() {
        return class_11941.field_62641;
    }
}