package com.imeetake.effectual.effects.SparksSoul;

import com.imeetake.tlib.client.particle.TOrientedParticle;
import net.minecraft.class_1058;
import net.minecraft.class_2400;
import net.minecraft.class_243;
import net.minecraft.class_3532;
import net.minecraft.class_4002;
import net.minecraft.class_4184;
import net.minecraft.class_4588;
import net.minecraft.class_638;

public class SoulSparkParticle extends TOrientedParticle<class_2400> {
    private final double roll;
    private final float rotSpeed;

    private final double driftAngle;
    private final double driftSpeed;
    private final double riseAccel;
    private final double turbulenceScale;

    protected double prevPosX, prevPosY, prevPosZ;

    public SoulSparkParticle(class_638 level,
                             double x, double y, double z,
                             double velocityX, double velocityY, double velocityZ,
                             class_4002 spriteSet) {
        super(level, x, y, z, velocityX, velocityY, velocityZ, spriteSet);

        this.scale = (0.02f + random.method_43057() * 0.01f) / 1.2f;

        this.lifetime = 40 + random.method_43048(20);
        this.alpha = 1.0F;

        float base = 0.9f + random.method_43057() * 0.1f;
        this.rCol = base * (0.05f + random.method_43057() * 0.05f);
        this.gCol = base * (0.75f + random.method_43057() * 0.15f);
        this.bCol = base * (0.95f + random.method_43057() * 0.05f);

        this.hasPhysics = false;
        this.gravity = 0.0F;

        this.xd = velocityX * 0.2;
        this.yd = velocityY * 0.2;
        this.zd = velocityZ * 0.2;

        this.roll = random.method_43058() * Math.PI * 2.0;
        this.rotSpeed = (random.method_43057() - 0.5f) * 0.1f;

        this.driftAngle = random.method_43058() * Math.PI * 2.0;
        this.driftSpeed = 0.0002 + random.method_43058() * 0.0003;
        this.riseAccel = 0.0015 + random.method_43058() * 0.001;
        this.turbulenceScale = 0.3 + random.method_43058() * 0.4;

        this.prevPosX = this.x;
        this.prevPosY = this.y;
        this.prevPosZ = this.z;
    }

    @Override
    public void tick() {
        this.prevPosX = this.x;
        this.prevPosY = this.y;
        this.prevPosZ = this.z;

        if (this.age++ >= this.lifetime) {
            this.remove();
            return;
        }

        float life = (float) this.age / (float) this.lifetime;

        double time = this.age * 0.15;
        double turbX = Math.sin(time + driftAngle) * Math.cos(time * 0.7) * turbulenceScale;
        double turbZ = Math.cos(time * 0.9 + driftAngle) * Math.sin(time * 0.6) * turbulenceScale;

        this.xd += Math.cos(driftAngle) * driftSpeed + turbX * 0.0001;
        this.zd += Math.sin(driftAngle) * driftSpeed + turbZ * 0.0001;

        double riseBoost = riseAccel * (1.0 - life * 0.5);
        this.yd += riseBoost;

        this.move(this.xd, this.yd, this.zd);

        double drag = 0.92 - life * 0.03;
        this.xd *= drag;
        this.yd *= drag;
        this.zd *= drag;

        float fadeStart = 0.7f;
        if (life > fadeStart) {
            float fadeProgress = (life - fadeStart) / (1.0f - fadeStart);
            this.alpha = 1.0f - smoothstep(0.0f, 1.0f, fadeProgress);
        } else {
            this.alpha = smoothstep(0.0f, 0.1f, life);
        }
    }

    @Override
    public void buildGeometry(class_4588 vc, class_4184 camera, float tickDelta) {
        float x = (float) class_3532.method_16436(tickDelta, this.prevPosX, this.x);
        float y = (float) class_3532.method_16436(tickDelta, this.prevPosY, this.y);
        float z = (float) class_3532.method_16436(tickDelta, this.prevPosZ, this.z);

        class_243 cam = camera.method_19326();
        class_243 center = new class_243(x - cam.field_1352, y - cam.field_1351, z - cam.field_1350);

        class_243 v = new class_243(this.xd, this.yd, this.zd);
        if (v.method_1027() < 1.0e-6) v = new class_243(0, 1, 0);

        class_243 up = v.method_1029();
        double currentRoll = this.roll + (this.age + tickDelta) * this.rotSpeed;

        class_243 tmp = Math.abs(up.field_1351) > 0.9 ? new class_243(1, 0, 0) : new class_243(0, 1, 0);
        class_243 right = up.method_1036(tmp).method_1029();
        right = rotateAroundAxis(right, up, currentRoll);

        float halfW = this.scale * 0.8f;
        float halfH = this.scale * 1.2f;

        class_243 u = up.method_1021(halfH);
        class_243 r = right.method_1021(halfW);

        class_243 p1 = center.method_1019(r).method_1019(u);
        class_243 p2 = center.method_1019(r).method_1020(u);
        class_243 p3 = center.method_1020(r).method_1020(u);
        class_243 p4 = center.method_1020(r).method_1019(u);

        var sprite = this.spriteSet.method_18138(this.age, this.lifetime);
        float u1 = sprite.method_4594();
        float u2 = sprite.method_4577();
        float v1 = sprite.method_4593();
        float v2 = sprite.method_4575();

        int light = 0xF000F0;

        vertex(vc, p1, u2, v1, light);
        vertex(vc, p2, u2, v2, light);
        vertex(vc, p3, u1, v2, light);
        vertex(vc, p4, u1, v1, light);

        vertex(vc, p4, u1, v1, light);
        vertex(vc, p3, u1, v2, light);
        vertex(vc, p2, u2, v2, light);
        vertex(vc, p1, u2, v1, light);
    }

    private void vertex(class_4588 vc, class_243 pos, float u, float v, int light) {
        vc.method_22912((float) pos.field_1352, (float) pos.field_1351, (float) pos.field_1350)
                .method_22913(u, v)
                .method_22915(this.rCol, this.gCol, this.bCol, this.alpha)
                .method_60803(light);
    }

    private class_243 rotateAroundAxis(class_243 vec, class_243 axis, double angle) {
        double c = Math.cos(angle);
        double s = Math.sin(angle);
        class_243 a = axis.method_1029();
        return vec.method_1021(c)
                .method_1019(a.method_1036(vec).method_1021(s))
                .method_1019(a.method_1021(a.method_1026(vec) * (1 - c)));
    }

    private float smoothstep(float edge0, float edge1, float x) {
        float t = class_3532.method_15363((x - edge0) / (edge1 - edge0), 0.0f, 1.0f);
        return t * t * (3.0f - 2.0f * t);
    }
}