package com.imeetake.effectual.effects.MouthSteam;

import com.imeetake.effectual.EffectualConfig;
import com.imeetake.effectual.ModParticles;
import com.imeetake.tlib.client.particle.TClientParticles;
import dev.architectury.event.events.client.ClientTickEvent;
import java.util.HashMap;
import java.util.Map;
import net.minecraft.class_1657;
import net.minecraft.class_2338;
import net.minecraft.class_5819;

public class MouthSteamEffect {

    private static final class_5819 RANDOM = class_5819.method_43047();
    private static final Map<Integer, Integer> tickCounters = new HashMap<>();
    private static final Map<Integer, MovementState> lastStates = new HashMap<>();

    public static void register() {
        ClientTickEvent.CLIENT_POST.register(client -> {
            if (!EffectualConfig.get().mouthSteam || client.field_1687 == null || client.method_1493()) return;

            for (class_1657 player : client.field_1687.method_18456()) {
                int id = player.method_5628();

                if (!shouldPlayEffect(player)) {
                    tickCounters.remove(id);
                    lastStates.remove(id);
                    continue;
                }

                MovementState current = getMovementState(player);
                MovementState previous = lastStates.getOrDefault(id, MovementState.STANDING);
                int tickCounter = tickCounters.getOrDefault(id, 0);
                if (current != previous) tickCounter = 0;
                tickCounter++;

                int frequency = getRandomFrequency(current);
                if (tickCounter >= frequency) {
                    spawnBreath(player);
                    tickCounter = 0;
                }

                tickCounters.put(id, tickCounter);
                lastStates.put(id, current);
            }
        });
    }

    private static boolean shouldPlayEffect(class_1657 player) {
        return isColdEnough(player)
                && !player.method_5869()
                && !player.method_7325()
                && !player.method_68878();
    }

    private static boolean isColdEnough(class_1657 player) {
        class_2338 pos = player.method_24515();
        return player.method_73183().method_23753(pos).comp_349().method_8712() < 0.15F;
    }

    private static void spawnBreath(class_1657 player) {
        int count = 3 + RANDOM.method_43048(3);

        for (int i = 0; i < count; i++) {
            TClientParticles.spawn(
                    ModParticles.MOUTH_STEAM.get(),
                    player.method_23317(), player.method_23320(), player.method_23321(),
                    0, 0, 0
            );
        }
    }

    private static int getRandomFrequency(MovementState state) {
        if (!EffectualConfig.get().dynamicBreathSpeed) return 90 + RANDOM.method_43048(21);
        return (state == MovementState.SPRINTING || state == MovementState.JUMPING)
                ? 30 + RANDOM.method_43048(21)
                : 90 + RANDOM.method_43048(21);
    }

    private static MovementState getMovementState(class_1657 p) {
        if (p.method_5624()) return MovementState.SPRINTING;
        if (!p.method_24828() && p.method_18798().field_1351 > 0.0) return MovementState.JUMPING;
        if (p.method_18798().method_37268() > 0.1) return MovementState.WALKING;
        return MovementState.STANDING;
    }

    private enum MovementState {
        STANDING, WALKING, SPRINTING, JUMPING
    }
}