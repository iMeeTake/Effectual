package com.imeetake.effectual.mixin;

import com.imeetake.effectual.effects.FireEntitySparks.FireEntitySparksEffect;
import net.minecraft.class_1297;
import net.minecraft.class_1937;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_1297.class)
public abstract class EntityMixin {

    @Shadow
    public abstract boolean isOnFire();

    @Shadow
    public class_1937 level;

    @Inject(method = "tick", at = @At("TAIL"))
    private void effectual$tick(CallbackInfo ci) {
        if (this.level.method_8608() && this.isOnFire()) {
            FireEntitySparksEffect.tick((class_1297) (Object) this);
        }
    }
}