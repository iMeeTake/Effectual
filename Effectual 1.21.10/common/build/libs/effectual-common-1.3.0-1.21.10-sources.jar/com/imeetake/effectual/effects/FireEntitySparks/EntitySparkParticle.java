package com.imeetake.effectual.effects.FireEntitySparks;

import net.minecraft.class_1058;
import net.minecraft.class_2400;
import net.minecraft.class_3940;
import net.minecraft.class_4002;
import net.minecraft.class_5819;
import net.minecraft.class_638;
import net.minecraft.class_703;
import net.minecraft.class_707;
import org.jetbrains.annotations.Nullable;

public class EntitySparkParticle extends class_3940 {

    private final float rotSpeed;
    private final float baseSize;

    public EntitySparkParticle(
            class_638 level,
            double x, double y, double z,
            double velocityX, double velocityY, double velocityZ,
            class_1058 sprite
    ) {
        super(level, x, y, z, velocityX, velocityY, velocityZ, sprite);

        this.baseSize = 0.015F * (1.0F + field_3840.method_43057() * 0.5F);
        this.field_17867 = this.baseSize;

        this.field_3847 = 15 + this.field_3840.method_43048(10);

        this.field_3862 = true;
        this.field_3844 = 0.0F;

        this.field_3852 = velocityX * 0.5;
        this.field_3869 = velocityY * 0.5;
        this.field_3850 = velocityZ * 0.5;

        float baseBrightness = 0.9f + field_3840.method_43057() * 0.1f;
        float r = baseBrightness * (0.9f + field_3840.method_43057() * 0.1f);
        float g = baseBrightness * (0.5f + field_3840.method_43057() * 0.4f);
        float b = baseBrightness * field_3840.method_43057() * 0.2f;

        this.method_74305(r, g, b);
        this.field_62636 = 1.0F;

        this.rotSpeed = (this.field_3840.method_43057() - 0.5F) * 0.15F;
        this.field_62637 = this.field_3840.method_43057() * (float) (Math.PI * 2);
        this.field_62638 = this.field_62637;
    }

    @Override
    public void method_3070() {
        this.field_3858 = this.field_3874;
        this.field_3838 = this.field_3854;
        this.field_3856 = this.field_3871;

        if (this.field_3866++ >= this.field_3847) {
            this.method_3085();
            return;
        }

        this.field_62638 = this.field_62637;
        this.field_62637 += this.rotSpeed;

        this.field_3869 += 0.001D;

        this.method_3069(this.field_3852, this.field_3869, this.field_3850);

        this.field_3852 *= 0.96;
        this.field_3869 *= 0.96;
        this.field_3850 *= 0.96;

        if (this.field_3866 > this.field_3847 / 2) {
            float progress = (float) (this.field_3866 - this.field_3847 / 2) / (this.field_3847 / 2);
            this.field_17867 = this.baseSize * (1.0F - progress);
        }
    }

    @Override
    public int method_3068(float partialTick) {
        return 15728880;
    }

    @Override
    protected class_11941 method_74255() {
        return class_11941.field_62641;
    }

    public static class Factory implements class_707<class_2400> {
        private final class_4002 spriteSet;

        public Factory(class_4002 spriteSet) {
            this.spriteSet = spriteSet;
        }

        @Nullable
        @Override
        public class_703 createParticle(class_2400 type, class_638 level, double x, double y, double z, double dx, double dy, double dz, class_5819 random) {
            EntitySparkParticle particle = new EntitySparkParticle(level, x, y, z, dx, dy, dz, this.spriteSet.method_18139(random));
            return particle;
        }
    }
}