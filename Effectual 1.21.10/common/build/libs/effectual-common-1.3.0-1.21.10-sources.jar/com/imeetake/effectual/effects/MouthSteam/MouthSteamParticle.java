package com.imeetake.effectual.effects.MouthSteam;

import net.minecraft.class_1058;
import net.minecraft.class_1657;
import net.minecraft.class_3532;
import net.minecraft.class_3940;
import net.minecraft.class_4002;
import net.minecraft.class_638;

public class MouthSteamParticle extends class_3940 {
    private final class_4002 spriteSet;
    private final class_1657 player;

    private final int detachTime;
    private double forwardOffset;
    private double exitSpeed;

    public MouthSteamParticle(
            class_638 level,
            class_1657 player,
            class_4002 spriteSet,
            class_1058 sprite
    ) {
        super(level, player.method_23317(), player.method_23320(), player.method_23321(), 0, 0, 0, sprite);
        this.spriteSet = spriteSet;
        this.player = player;

        this.field_17867 = 0.035F + this.field_3840.method_43057() * 0.05F;
        this.field_3847 = 30 + this.field_3840.method_43048(10);
        this.detachTime = 6 + this.field_3840.method_43048(4);

        this.exitSpeed = 0.06 + this.field_3840.method_43058() * 0.03;
        this.forwardOffset = 0.2;

        this.field_3844 = 0.0F;
        this.field_3862 = false;
        this.field_62636 = 0.6F;

        this.method_74306(this.spriteSet);

        this.updateAttachedPosition();
    }

    @Override
    public void method_3070() {
        this.field_3858 = this.field_3874;
        this.field_3838 = this.field_3854;
        this.field_3856 = this.field_3871;

        if (this.field_3866++ >= this.field_3847) {
            this.method_3085();
            return;
        }

        if (this.field_3866 <= this.detachTime) {
            if (!this.player.method_5805() || this.player.method_73183() != this.field_3851) {
                this.method_3085();
                return;
            }

            this.forwardOffset += this.exitSpeed;
            this.exitSpeed *= 0.9;

            this.field_17867 += 0.008F;

            updateAttachedPosition();
        } else {
            this.field_3869 = 0.005;
            this.method_3069(this.field_3852, this.field_3869, this.field_3850);

            this.field_3852 *= 0.95;
            this.field_3850 *= 0.95;
        }

        float lifeRatio = (float) this.field_3866 / (float) this.field_3847;
        this.field_62636 = 0.6F - (lifeRatio * 0.6F);

        this.method_74306(this.spriteSet);
    }

    private void updateAttachedPosition() {
        float yaw = (float) Math.toRadians(this.player.method_36454());
        float pitch = (float) Math.toRadians(this.player.method_36455());

        double lookX = -class_3532.method_15374(yaw) * class_3532.method_15362(pitch);
        double lookY = -class_3532.method_15374(pitch);
        double lookZ = class_3532.method_15362(yaw) * class_3532.method_15362(pitch);

        double targetX = this.player.method_23317() + (lookX * this.forwardOffset);
        double targetY = (this.player.method_23320() - 0.15) + (lookY * this.forwardOffset);
        double targetZ = this.player.method_23321() + (lookZ * this.forwardOffset);

        this.method_3063(targetX, targetY, targetZ);

        this.field_3852 = lookX * 0.02;
        this.field_3850 = lookZ * 0.02;
    }

    @Override
    protected class_11941 method_74255() {
        return class_11941.field_62641;
    }
}