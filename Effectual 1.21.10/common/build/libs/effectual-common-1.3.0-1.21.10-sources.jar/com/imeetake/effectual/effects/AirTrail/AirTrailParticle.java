package com.imeetake.effectual.effects.AirTrail;

import com.imeetake.tlib.client.particle.TOrientedParticle;
import com.imeetake.tlib.client.render.TClientRenderUtils;
import net.minecraft.class_1058;
import net.minecraft.class_2400;
import net.minecraft.class_243;
import net.minecraft.class_3532;
import net.minecraft.class_4002;
import net.minecraft.class_4184;
import net.minecraft.class_4588;
import net.minecraft.class_638;

public class AirTrailParticle extends TOrientedParticle<class_2400> {
    private final class_243 initialVelocity;

    public AirTrailParticle(class_638 level,
                            double x, double y, double z,
                            double velocityX, double velocityY, double velocityZ,
                            class_4002 spriteSet) {
        super(level, x, y, z, velocityX, velocityY, velocityZ, spriteSet);

        this.scale = 0.04f + random.method_43057() * 0.01f;
        this.lifetime = 10 + random.method_43048(5);
        this.alpha = 0.4f;

        this.setColor(0.9f, 0.95f, 1.0f);

        this.initialVelocity = new class_243(velocityX, velocityY, velocityZ);
        this.gravity = 0.01f;
    }

    @Override
    public void tick() {
        super.tick();

        this.xd *= 0.98;
        this.yd *= 0.98;
        this.zd *= 0.98;

        float ageRatio = (float) this.age / this.lifetime;
        float alphaFactor = 1.0f - (ageRatio * ageRatio);
        this.alpha = 0.4f * alphaFactor;

        this.scale = (0.15f + random.method_43057() * 0.1f) * (1.0f + ageRatio * 0.3f);
    }

    @Override
    public void buildGeometry(class_4588 vc, class_4184 camera, float tickDelta) {
        float px = (float) class_3532.method_16436(tickDelta, this.xo, this.x);
        float py = (float) class_3532.method_16436(tickDelta, this.yo, this.y);
        float pz = (float) class_3532.method_16436(tickDelta, this.zo, this.z);

        class_243 camPos = camera.method_19326();
        class_243 center = new class_243(px - camPos.field_1352, py - camPos.field_1351, pz - camPos.field_1350);

        class_243 motion = this.initialVelocity;
        if (motion.method_1027() < 0.0001) {
            motion = new class_243(0, 0, 1);
        }

        class_243 forward = motion.method_1029().method_1021(this.scale * 6.0);
        class_243 cameraLook = TClientRenderUtils.getCameraLookVector().method_1029();

        class_243 up = cameraLook.method_1036(forward).method_1029().method_1021(this.scale * 0.25);

        double rotationAngle = Math.PI * 0.05 * (random.method_43056() ? 1 : -1);
        class_243 rotationAxis = forward.method_1029();

        class_243 upRotated = rotateVectorAroundAxis(up, rotationAxis, rotationAngle);

        if (upRotated.method_1027() < 0.001) {
            upRotated = rotateVectorAroundAxis(
                    new class_243(0, 1, 0).method_1036(forward).method_1029().method_1021(this.scale * 0.25),
                    rotationAxis,
                    rotationAngle
            );
        }

        class_243 p1 = center.method_1019(forward.method_1021(0.5)).method_1019(upRotated);
        class_243 p2 = center.method_1019(forward.method_1021(0.5)).method_1020(upRotated);
        class_243 p3 = center.method_1020(forward.method_1021(0.5)).method_1020(upRotated);
        class_243 p4 = center.method_1020(forward.method_1021(0.5)).method_1019(upRotated);

        var sprite = this.spriteSet.method_18138(this.age, this.lifetime);
        float u1 = sprite.method_4594();
        float u2 = sprite.method_4577();
        float v1 = sprite.method_4593();
        float v2 = sprite.method_4575();
        int light = this.getLightColor(tickDelta);

        vertex(vc, p1, u2, v1, light);
        vertex(vc, p2, u2, v2, light);
        vertex(vc, p3, u1, v2, light);
        vertex(vc, p4, u1, v1, light);
    }

    private void vertex(class_4588 vc, class_243 pos, float u, float v, int light) {
        vc.method_22912((float) pos.field_1352, (float) pos.field_1351, (float) pos.field_1350)
                .method_22913(u, v)
                .method_22915(this.rCol, this.gCol, this.bCol, this.alpha)
                .method_60803(light);
    }

    private class_243 rotateVectorAroundAxis(class_243 vector, class_243 axis, double angle) {
        double cos = Math.cos(angle);
        double sin = Math.sin(angle);

        return vector.method_1021(cos)
                .method_1019(axis.method_1036(vector).method_1021(sin))
                .method_1019(axis.method_1021(axis.method_1026(vector) * (1 - cos)));
    }
}